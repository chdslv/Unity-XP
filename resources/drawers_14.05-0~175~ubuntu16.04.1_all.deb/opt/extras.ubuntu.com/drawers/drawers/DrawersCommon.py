from urllib2 import url2pathname
from xdg.DesktopEntry import DesktopEntry
import os,getpass
from ConfigParser import ConfigParser
from gi.repository import Gio, Gtk,Unity
import locale
from locale import gettext as _
from xdg.Mime import get_type

locale.textdomain('drawers')
#locale.setlocale(locale.LC_ALL,'es_PR.UTF-8')
#necessary to get import applications to keep their local names
import xdg.Locale
lang=locale.getdefaultlocale()[0]
xdg.Locale.langs=[lang,lang[:2]]

BASENAME='/home/' + getpass.getuser()
SEARCH_DIRS=['/usr/share/applications',BASENAME+'/.local/share/applications']
USER=user=getpass.getuser()

i=0
debug=True
iconpath="/opt/extras.ubuntu.com/drawers/share/drawers/media/"
settings = Gio.Settings("net.launchpad.drawers")
NUM_OPEN = settings.get_int("number-open") + 1
settings.set_int("number-open", NUM_OPEN)
REMINDER_NUM = settings.get_int("reminder-num")
BAD_CHARS=[';','[',']']

#REMINDER_NUM = 1
DONATE_URL = 'https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=GRXNFZQH5N7JS&lc=US&item_name=Drawers%20Development&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted'.replace('&','&amp;')

def dbg(flag,msg):
    if flag:
        print msg

class UnityLauncher(Gio.Settings):
    KEY = 'favorites'

    def __init__(self):
        Gio.Settings.__init__(self, 'com.canonical.Unity.Launcher')

    def exists(self, launcher):
        return launcher in self[self.KEY]

    def add(self, launcher):
        """Ensure that launcher is present in Unity gsettings"""
        launchers = self[self.KEY]
        if launcher not in launchers:
            launchers.append(launcher)
            self[self.KEY] = launchers
            return True

    def remove(self, launcher):
        """Remove launcher from Unity gsettings"""
        launchers = self[self.KEY]
        try:
            launchers.remove(launcher)
            self[self.KEY] = launchers
            return True
        except ValueError:
            #not present
            pass

class DrawerConfig(object):
    def __init__(self,fn=''):
        self.fn=fn
        self.localfn='/home/%s/.config/drawers/%s'%(USER,fn)
        self.settings=Gio.Settings("net.launchpad.drawers")
        self.config = ConfigParser()
        self.read=self.readlocal()
        print "intializing config"
        
    def readlocal(self):
        if self.fn!='' and os.path.isfile(self.localfn):
            try:
                
                self.config.read(self.localfn)
                print "file read"
                return True
            except:
                return False
        else:
            return False
    def savelocal(self):
        with open(self.localfn, 'w') as fn:
            self.config.write(fn)
    @property 
    def LOCALSET(self):
        if self.read:
            try:
                return self.config.getboolean('Drawer','localset')
            except:
                dbg(True,"Error reading localconfig file, falling back to global settings")
                return False
        else:
            return False
    @property
    def REMEMBER(self):
        if None not in self.POSITION:
            return True
        else:
            return False
    @property
    def FULLSCREEN(self):
        if self.LOCALSET:
            try:
                return self.config.getboolean('Drawer','fullscreen')
            except NoOptionError:
                self.config.set('Drawer','fullscreen','false')
                self.savelocal()
                return False
            except Exception as e:
                print "Error checking Fullscreen in localconfig"
                return False
        else:
            return self.settings.get_boolean('fullscreen')
    @property
    def xpos(self):
        if self.LOCALSET:
            print "getting"
            return self.config.getint('Drawer','xpos')
    @xpos.setter
    def xpos(self,value):
        if self.LOCALSET:
            print "setting"
            self.config.set('Drawer','xpos', str(value))
    @property
    def ypos(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','ypos')
    @ypos.setter
    def ypos(self,value):
        if self.LOCALSET:
            self.config.set('Drawer','ypos',str(value))
    @property
    def POSITION(self):
        if self.LOCALSET:
            try:
                return [self.xpos,self.ypos]
            except:
                dbg(True,'No position found in local config')
                return (None, None)
        else:
            return (None, None)
    @POSITION.setter
    def POSITION(self,tup):
        print type(tup)
        x,y=tup
        if self.LOCALSET:
            print "setting position to %s,%s"%(x,y)
            self.xpos=x
            self.ypos=y
            #self.config.set('Drawer','xpos', x)
            #self.config.set('Drawer','ypos', y)
            #self.savelocal()
            print self.POSITION
    @property
    def PINSTATE(self):
        if self.LOCALSET:
            try:
                return self.config.get('Drawer','PinState')
            except:
                return 'None'
        else:
            return 'None'
    @PINSTATE.setter
    def PINSTATE(self, string):
        if self.LOCALSET:
            self.config.set('Drawer','PinState', string)
            print "Set pinstate to %s" %string
    @property
    def SORTSTATE(self):
        if self.LOCALSET:
            try:
                return self.config.get('Drawer','SortState')
            except:
                return 'None'
        else:
            return 'None'
    @SORTSTATE.setter
    def SORTSTATE(self, string):
        if self.LOCALSET:
            self.config.set('Drawer','SortState', string)
    
    @property
    def ICONSIZE(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','iconsize')
        else:
            return self.settings.get_int("iconsize")
    
    @property
    def FONTSIZE(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','fontsize')
        else:
            return self.settings.get_int("fontsize")
    @property
    def MAXICONS_ROW(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','maxicons_row')
        else:
            return self.settings.get_int("maxicons-row")
    @property
    def HIDE_BUTTONS(self):
        if self.LOCALSET:
            try:
                return self.config.getboolean('Drawer','hide_buttons')
            except KeyError:
                self.config.set('Drawer','hide_buttons',settings.get_boolean("hide-buttons"))
        return self.settings.get_boolean("hide-buttons")
    @property
    def BORDER(self):
        if self.LOCALSET:
            try:
                return self.config.getboolean('Drawer','border')
            except KeyError:
                self.config.set('Drawer','border',settings.get_boolean("border"))
        else:
            return self.settings.get_boolean("border")
    @property
    def MARGIN(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','margin')
        else:
            return self.settings.get_int("margin")
    @property
    def TRANSPARENCY(self):
        if self.LOCALSET:
            return self.config.getfloat('Drawer','transparency')
        else:
            return self.settings.get_double("transparency")
    @property
    def COLOR_SCALING(self):
        if self.LOCALSET:
            return self.config.getfloat('Drawer','color_scaling')
        else:
            return self.settings.get_double("color-scaling")
    @property
    def COLUMN_SPACING(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','column_spacing')
        else:
            return self.settings.get_int("column-spacing")
    @property
    def ITEM_WIDTH(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','item_width')
        else:
            return self.settings.get_int("item-width")

    @property
    def LIMIT_QUICKLIST(self):
        if self.LOCALSET:
            return self.config.getboolean('Drawer','limit_quicklist')
        else:
            return self.settings.get_boolean("limit-quicklist")
    @property
    def QUICKLIST_MAX(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','quicklist_max')
        else:
            return self.settings.get_int("quicklist-max")
    @property
    def DEADREMOVE(self):
        return self.settings.get_boolean("dead-remove")
    @property
    def DEADCONFIRM(self):
        return self.settings.get_boolean("dead-confirm")
    @property
    def TEXT_ELLIPS(self):
        if self.LOCALSET:
            return self.config.getint('Drawer','text_ellips')
        else:
            return self.settings.get_int("text-ellips")
    @property
    def LIMIT_TEXT(self):
        if self.LOCALSET:
            return self.config.getboolean('Drawer','limit_text')
        else:
            return self.settings.get_boolean("limit-text")
    @property
    def FOCUS_REQ(self):
        return settings.get_boolean("focus-req")
    @property
    def AUTO_LAYOUT(self):
        if self.LOCALSET:
            return self.config.getboolean('Drawer','auto_layout')
        else:
            return self.settings.get_boolean("auto-layout")
    @property
    def RESET_QUICKLIST(self):
        return False
    @property
    def FIRST_RUN(self):
        return self.settings.get_boolean("first-run")
    @FIRST_RUN.setter
    def FIRST_RUN(self, value):
        if type(value)==bool:
            self.settings.set_boolean("first-run", value)
        else:
            raise TypeError
    @property
    def KEY(self):
        return self.settings.get_int('reminder-num')
    @KEY.setter
    def KEY(self, value):
        value=int(value)
        self.settings.set_int('reminder-num', value)

def writeconfig(fn,localset=False):
    """reads a config file for a drawer, option to have drawer specific configs"""
    global ICONSIZE
    global FONTSIZE
    global MAXICONS_ROW
    global MARGIN
    global TRANSPARENCY
    global COLOR_SCALING
    global COLUMN_SPACING
    global ITEM_WIDTH
    global LIMIT_QUICKLIST
    global QUICKLIST_MAX
    global TEXT_ELLIPS
    global LIMIT_TEXT
    settings=['ICONSIZE', 
            'FONTSIZE',
            'MAXICONS_ROW',
            'MARGIN',
            'TRANSPARENCY',
            'COLOR_SCALING',
            'COLUMN_SPACING',
            'ITEM_WIDTH',
            'LIMIT_QUICKLIST',
            'QUICKLIST_MAX',
            'TEXT_ELLIPS',
            'BORDER',
            'HIDE_BUTTONS',
            'LIMIT_TEXT']
    config=ConfigParser()
    config.add_section('Drawer')
    for setting in settings:
        config.set('Drawer',setting.lower(), value=globals()[setting])
    config.set('Drawer','localset',value=localset)
    try:
        if not os.path.exists('/home/'+USER+'/.config/drawers'):
            os.mkdir('/home/'+USER+'/.config/drawers')
        with open('/home/'+USER+'/.config/drawers/'+fn,'w') as openfile:
            config.write(openfile)
    except Exception as e:
        print "Problem writing config file: %s"%fn
        print repr(e)
        
def get_icon_size(debug=False):
    environ=os.environ['DESKTOP_SESSION']
    if environ=='ubuntu':
        try:
            if 'org.compiz.unityshell' in Gio.Settings.list_relocatable_schemas():
                dbg(debug, "Getting iconsize from GSettings")
                settings=Gio.Settings.new_with_path('org.compiz.unityshell','/')
                return settings.get_int('icon-size')
            else:
                import compizconfig
                context=compizconfig.Context()
                unityshell=context.Plugins['unityshell']
                ics=unityshell.Screen['icon_size']
                return int(ics.Value)
        except Exception as e:
            dbg(debug, "Couldn't get icon_size from compizconfig")
            dbg(debug, repr(e))
    elif environ=='ubuntu-2d':
        shell_qml = "/usr/share/unity-2d/shell/Shell.qml"
        if os.path.isfile(shell_qml):
            with file(shell_qml, 'r') as unity2d:
                lines=unity2d.readlines()
            index=0
            for line in lines:
                if line.lstrip().startswith('LauncherLoader {'):
                    break
                index+=1
            for line in lines[index:]:
                if line.lstrip().startswith('width:'):
                    size=line.strip().replace('width: ','')
                    return int(size)-28
        
        return None

def getactions(df):
    if df.hasKey('Actions','Desktop Entry'):
        prefix='Desktop Action '
        suffix=''
        actions=df.get('Actions','Desktop Entry').rstrip(';').split(';')
    elif df.hasKey('X-Ayatana-Desktop-Shortcuts','Desktop Entry'):
        prefix=''
        suffix=' Shortcut Group'
        actions=df.get('X-Ayatana-Desktop-Shortcuts','Desktop Entry').rstrip(';').split(';')
    else:
        prefix = suffix = None
        actions=None
    return actions, prefix, suffix
    
def add_file(self, addfile):
    """function to add a corresponding desktop action entry from a uri
    will parse the input to name the item the last name in a path or the
    first portion of a network protocol"""
    dbg(self.debug, "Adding file %s" %addfile)
    filetype=get_mimetype(url2pathname(addfile.strip('"')))

    name=filter(None,addfile.rstrip('/').split('/'))

    if name[0] in ['http:','https:','ssh:','ftp:']:
        name=name[1]
        filetype='url'
    else:
        addfile=url2pathname(addfile)
        dbg(self.debug, "reformatted file with url2pathname: %s" %addfile)

        name=filter(None,addfile.rstrip('/').split('/'))
        name=name[-1].replace('.desktop','')
    
    if name in self.actions and filetype=='url':
        dbg(self.debug, "name is already present in actions: %s"%str(self.actions))
        count=1
        origname=name
        while name in self.actions:
            name=origname+'_%i'%count
            count+=1
        
    #icon=self.get_icon_filename(addfile, ICONSIZE)
    icon=get_icon_name(addfile)
    if addfile.split('.')[-1]=='desktop':
        if addfile.split('://')[0]=='application':
            AIManager=Unity.AppInfoManager.get_instance()
            addfile=AIManager.get_path(addfile.split('://')[-1])
        newdf=DesktopEntry(addfile)
        groupentry={}
        for key in ['Name','Exec','Icon']:
            groupentry[key]=newdf.get(key,'Desktop Entry',locale=True)
        name = groupentry['Name']
        if name in self.actions: return
        for uri in [' %u',' %U',' %f',' %F',' %s',' %S']:
            groupentry['Exec']=groupentry['Exec'].replace(uri,'')
        if newdf.hasKey('Terminal','Desktop Entry'):
            if newdf.get('Terminal','Desktop Entry').lower()=='true':
                groupentry['Exec']='x-terminal-emulator -e '+groupentry['Exec']
        if newdf.hasKey('Path','Desktop Entry'):
                groupentry['Path']=newdf.get('Path','Desktop Entry')
        #groupentry['Exec']=' "'.join(groupentry['Exec'].split(' ',1))+'"'
        groupentry['Type']=filetype
        groupentry['OnlyShowIn']='Unity'
        
        actions,prefix,suffix=getactions(newdf)
        
        if actions!=None:
            
            dbg(self.debug,"Adding Quicklist Actions: %s" %str(actions))
            groupentry['Actions']=len(actions)
            QLnames=[]
            QLexecs=[]
            for action in actions:
                group=prefix+action+suffix
                QLnames.append(newdf.get('Name',group,locale=True))
                execline=newdf.get('Exec',group)
                try:
                    if newdf.get('Terminal',group).lower()=='true':
                        execline='x-terminal-emulator -e '+execline
                except:
                    pass
                QLexecs.append(execline)
                
    else:
        actions=None
        groupentry={'Name':name,
                'Exec':'xdg-open "' + addfile+'"' ,
                'Type':filetype,
                'Icon':icon,
                'OnlyShowIn':'Unity;'}
    name=name.replace(';','').replace('[','').replace(']','')
    group='Desktop Action ' + name
    dbg(self.debug, " Name: %s \n Exec: %s \n Type: %s \n Icon: %s"%(groupentry['Name'],
                                                                     groupentry['Exec'],
                                                                     groupentry['Type'],
                                                                     groupentry['Icon']))        
        
        
    self.df.addGroup(group)
    for key in groupentry:
        self.df.set(key,groupentry[key],group)
    
    if actions != None:
        self.df.addGroup('Drawer Action '+name)
        for num in range(0,len(actions)):
            self.df.set('Name[%i]'%num,QLnames[num],'Drawer Action '+name)
            self.df.set('Exec[%i]'%num,QLexecs[num],'Drawer Action '+name)
    
    dbg(self.debug, 'Original Actions: %s'%';'.join(self.actions))
    dbg(self.debug, 'Adding name to actions: %s'%name)
    self.actions.append(name)
    self.df.set('Actions', ';'.join(self.actions),'Desktop Entry')
    dbg(self.debug, " Actions: %s"%';'.join(self.actions)+';')
    savedf(self)

def savedf(self):
    if self.config.LIMIT_QUICKLIST:
        self.resetquicklist()
        if self.config.QUICKLIST_MAX<len(self.actions):
            hidelist=self.actions[self.config.QUICKLIST_MAX:]
            for action in hidelist:
                if self.df.hasKey('PinToQuicklist','Desktop Action '+action) and self.df.get('PinToQuicklist','Desktop Action '+action)=='True':
                    continue
                else:
                    self.df.set('OnlyShowIn','','Desktop Action '+action)
    #To update older Drawers
    if not self.df.hasKey('StartupWMClass','Desktop Entry'):
        self.df.set('StartupWMClass','Drawers '+ self.filename.split('/')[-1].replace('.desktop',''),'Desktop Entry')
    try:
        self.df.write(self.filename)
    except Exception as e:
        dbg(self.debug, repr(e))

def get_icon_filename(filename,size):
    ##final_filename = "default_icon.png"
    final_filename = ""
    if os.path.isfile(filename):
        # Get the icon name
        file_res = Gio.File.new_for_path(filename)
        file_info = file_res.query_info('standard::icon',Gio.FileQueryInfoFlags.NONE,Gio.Cancellable())
        file_icon = file_info.get_icon().get_names()[0]
        # Get the icon file path
        icon_theme = Gtk.IconTheme.get_default()
        icon_filename = icon_theme.lookup_icon(file_icon, size, 0)
        if icon_filename != None:
            final_filename = icon_filename.get_filename()

    return final_filename

def get_icon_name(filename):
    ##final_filename = "default_icon.png"
    file_icon = ""
    icon_theme = Gtk.IconTheme.get_default()
    if os.path.isfile(filename):
        # Get the icon name
        file_res = Gio.File.new_for_path(filename)
        file_info = file_res.query_info('standard::icon',Gio.FileQueryInfoFlags.NONE,Gio.Cancellable())

        icons = [name for name in file_info.get_icon().get_names() if name !='(null)']
        dbg(debug, file_icon)
        for icon in icons:
            if icon_theme.lookup_icon(icon, 32, 0)!=None:
                file_icon=icon
                break
    dbg(debug, file_icon)
    return file_icon

def getText(parent,Message=None, label=_("Name:"), Message2=None, Entry=None):
    #base this on a message dialog
    dialog = Gtk.MessageDialog(
        parent,
        1,
        Gtk.MessageType.QUESTION,
        Gtk.ButtonsType.OK_CANCEL,
        None)
    dialog.set_markup(Message)
    #create the text input field
    entry = Gtk.Entry()
    if Entry != None: entry.set_text(Entry)
    #allow the user to press enter to do ok
    #entry.connect("activate", parent.responseToDialog, dialog, Gtk.ResponseType.OK)
    #create a horizontal box to pack the entry and a label
    hbox = Gtk.HBox()
    hbox.pack_start(Gtk.Label(label), False, 5, 5)
    hbox.pack_end(entry,True,True,0)
    #some secondary text
    if Message2 != None: dialog.format_secondary_markup(Message2)
    #add it and show it
    dialog.vbox.pack_end(hbox, True, True, 0)
    dialog.show_all()
    #go go go
    text = None
    response = dialog.run()
    if response == Gtk.ResponseType.OK:
        text=entry.get_text()
        if text=='': text=None #Don't overwrite with Nothing!
    dialog.destroy()
    return text

def get_mimetype(path):
    mime=get_type(path)
    return str(mime).split('/')[0]
