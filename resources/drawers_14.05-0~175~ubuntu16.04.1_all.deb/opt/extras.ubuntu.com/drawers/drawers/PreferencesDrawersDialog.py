# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2012 Ian Berke ian.berke@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# This is your preferences dialog.
#
# Define your preferences in
# data/glib-2.0/schemas/net.launchpad.drawers.gschema.xml
# See http://developer.gnome.org/gio/stable/GSettings.html for more info.

from gi.repository import Gio,Gtk,GdkPixbuf # pylint: disable=E0611

import locale
from locale import gettext as _
locale.textdomain('drawers')

import logging
logger = logging.getLogger('drawers')

import subprocess, getpass,os
from xdg.DesktopEntry import DesktopEntry
from ConfigParser import ConfigParser
USER=getpass.getuser()

global debug
from drawers_lib.PreferencesDialog import PreferencesDialog
from drawers.DrawersCommon import *
settings={'ICONSIZE':'int',
            'FONTSIZE':'int',
            'MAXICONS_ROW':'int',
            'MARGIN':'int',
            'TRANSPARENCY':'double',
            'COLOR_SCALING':'double',
            'COLUMN_SPACING':'int',
            'ITEM_WIDTH':'int',
            'LIMIT_QUICKLIST':'boolean',
            'QUICKLIST_MAX':'int',
            'TEXT_ELLIPS':'int',
            'BORDER':'boolean',
            'HIDE_BUTTONS':'boolean',
            'LIMIT_TEXT':'boolean',
            'AUTO_LAYOUT':'boolean'}

class PreferencesDrawersDialog(PreferencesDialog):
    __gtype_name__ = "PreferencesDrawersDialog"
    
    def __new__(cls, fn,debug=False):
        cls.df=DesktopEntry(fn)
        cls.iconfn=cls.df.get('Icon','Desktop Entry')
        cls.name=cls.df.get('Name','Desktop Entry')
        if ' -a ' in cls.df.get('Exec', 'Desktop Entry'):
            cls.active=True
        else:
            cls.active=False
        if cls.df.hasKey('Path', 'Desktop Entry'):
            cls.path=cls.df.get('Path', 'Desktop Entry')
        else:
            cls.path=None
        cls.fn=fn
        cls.debug=debug
        cls.conffn='/home/'+USER+'/.config/drawers/'+fn.split('/')[-1].replace('.desktop','.conf')
        newobject=super(PreferencesDrawersDialog,cls).__new__(cls)
        return newobject
        
    def finish_initializing(self, builder):#, conf_file='default.conf'): # pylint: disable=E1002
        """Set up the preferences dialog"""
        super(PreferencesDrawersDialog, self).finish_initializing(builder)
        self.initializing=True
        self.local = False
        #print self.conffn
        self.autostart='/home/'+USER+'/.config/autostart/'+self.fn.split('/')[-1]

        self.settings = Gio.Settings("net.launchpad.drawers")
        if os.path.isfile(self.conffn):
            self.local=self.read_local_config()
            dbg(self.debug, "Using local settings: %s"%self.local)
            if self.local:
                toggle=self.builder.get_object('local_setting')
                toggle.set_active(True)
                self.bind_local_settings()
            else:
                self.bind_global_settings()
        else:
            dbg(self.debug, "No local config file found, using global bindings")
            self.bind_global_settings()
        
        if self.active:
            box=self.builder.get_object('box2')
            cont=Gtk.Box()
            label=Gtk.Label(_('Path to display:'))
            label.show()
            cont.pack_start(label,False,False,5)
            self.pathentry=Gtk.Button()
            self.pathentry.set_label(self.path)
            self.pathentry.set_alignment(0.0, 0.5)
            self.pathentry.connect('clicked', self.choose_activepath)
            self.pathentry.show()
            cont.pack_start(self.pathentry,True,True,5)
            cont.show()
            box.pack_end(cont,False,False,5)
        toggle_action=self.builder.get_object('action_localsetting')
        toggle_action.connect('toggled', self.on_toggle)
        autostart_check=self.builder.get_object('autostart')
        if os.path.exists(self.autostart):
            autostart_check.set_active(True)
                   
        numopen = self.builder.get_object('NumOpen')
        numopen.set_text("%i" % self.settings.get_int('number-open'))
        widget = self.builder.get_object('dead_remove')
        self.settings.bind("dead-remove", widget, "active", Gio.SettingsBindFlags.DEFAULT)
        
        widget = self.builder.get_object('dead_confirm')
        self.settings.bind("dead-confirm", widget, "active", Gio.SettingsBindFlags.DEFAULT)
        
        widget = self.builder.get_object('focus_req')
        self.settings.bind("focus-req", widget, "active", Gio.SettingsBindFlags.DEFAULT)
        
        self.icon=Gtk.Image()
        try:
            pixbuf=GdkPixbuf.Pixbuf.new_from_file(self.iconfn).scale_simple(64,64,GdkPixbuf.InterpType.BILINEAR)
        except:
            pixbuf=Gtk.IconTheme.get_default().load_icon('image-missing', 64, 0)
        self.icon.set_from_pixbuf(pixbuf)
        self.icon.show()
        
        iconbutton = self.builder.get_object('iconbutton')
        iconbutton.add(self.icon)
        
        iconbutton.connect('activate', self.on_iconbutton_clicked)
        
        action_edit=self.builder.get_object('action_edit')
        action_edit.connect('activate', self.on_edit_activate)
        
        action_localsetting=self.builder.get_object('action_localsetting')
        action_localsetting.connect('toggled', self.on_toggle)
        
        self.name_entry=self.builder.get_object('name_entry')
        self.name_entry.set_text(self.name)
        print self.settings.get_int('reminder-num')
        if self.settings.get_int('reminder-num')==2147483647:
            self.donated(True)
        self.initializing=False
        
    def choose_activepath(self,widget,data=None):
        filedialog=Gtk.FileChooserDialog(
            _('Choose a Folder for your Active Drawer'),
            self,
            Gtk.FileChooserAction.SELECT_FOLDER,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        #Add Filter to only show/choose directories
        filter_folder= Gtk.FileFilter()
        filter_folder.set_name(_("Folders"))
        filter_folder.add_mime_type("inode/directory")
        filedialog.add_filter(filter_folder)
        filedialog.set_current_folder(self.path)
        path=None
        response=filedialog.run()
        
        if response == Gtk.ResponseType.OK:

            path=filedialog.get_filename()
            
            dbg(self.debug, "Chose %s"% path)
        filedialog.destroy()
        if path==None:
            return
        else:
            self.path=path
            self.pathentry.set_label(self.path)
            
    def on_auto_layout_toggled(self, widget, data=None):
        self.auto_layout=widget.get_active()
        maxicons_widget=self.builder.get_object('maxicons_row')
        if self.auto_layout:
            maxicons_widget.set_editable(False)
        else:
            maxicons_widget.set_editable(True)
    def on_toggle(self, widget, data=None):
        dbg(self.debug, "checking toggle stat")
        if widget.get_active():
            dbg(self.debug, "toggle active, unbinding")
            #Check for existance of local settings, if none, create it using defaults
            
            if not os.path.isfile(self.conffn):            
                if not os.path.exists('/home/'+USER+'/.config/drawers'):
                    os.mkdir('/home/'+USER+'/.config/drawers')
                self.config=ConfigParser()
                self.config.add_section('Drawer')
                self.config.set('Drawer','localset',True)
                self.save_local_settings()
            else:
                self.read_local_config()
                self.config.set('Drawer','localset',True)
                self.save_local_settings(False)

            
            #then close preference window and reopen
            self.destroy()
            #self.unbind_global_settings()
        else:
            dbg(self.debug, "toggle deactivated, switching to global settings")
            self.config.set('Drawer', 'localset', False)
            self.save_local_settings()
            self.destroy()
    def bind_global_settings(self):
        # Bind each preference widget to gsettings
        self.settings = Gio.Settings("net.launchpad.drawers")
        for key in settings.keys():
            widget = self.builder.get_object(key.lower())
            if settings[key]=='boolean':
                self.settings.bind(key.lower().replace('_','-'), widget, "active", Gio.SettingsBindFlags.DEFAULT)
            else:
                self.settings.bind(key.lower().replace('_','-'), widget, "value", Gio.SettingsBindFlags.DEFAULT)
    
    def bind_local_settings(self):
        for key in settings.keys():
            #print key, getattr(self, key)
            widget = self.builder.get_object(key.lower())
            if settings[key]=='boolean':
                widget.set_active(getattr(self,key))
            else:
                widget.set_value(getattr(self,key))
    
    def save_local_settings(self, update=True, reset=False):
        if reset:
            self.settings = Gio.Settings("net.launchpad.drawers")
        if update:
            for key in settings.keys():
                widget = self.builder.get_object(key.lower())
                
                if settings[key]=='boolean':
                    if reset:
                        active=self.settings.get_boolean(key.lower().replace('_','-'))
                    else:
                        active = widget.get_active()
                    #print key, ' was ', getattr(self, key), ' is now ', active
    
                    setattr(self,key,active)
                    self.config.set('Drawer',key.lower(),active)
                elif settings[key]=='int':
                    if reset:
                        value=self.settings.get_int(key.lower().replace('_','-'))
                    else:
                        value = int(widget.get_value())
                    #print key, ' was ', getattr(self, key), ' is now ', value
                    
                    setattr(self,key,value)
                    self.config.set('Drawer',key.lower(),value)
                elif settings[key]=='double':
                    if reset:
                        value=self.settings.get_double(key.lower().replace('_','-'))
                    else:
                        value = float(widget.get_value())
                    #print key, ' was ', getattr(self, key), ' is now ', value
                    
                    setattr(self,key,value)
                    self.config.set('Drawer',key.lower(),value)
                
        with open(self.conffn, 'w') as fn:
            self.config.write(fn)
    def unbind_global_settings(self):
        self.settings = Gio.Settings("net.launchpad.drawers")
        print "unbinding"
        for key in settings.keys():
            print key
            widget = self.builder.get_object(key.lower())
            print "got widget"
            if settings[key]=='boolean':
                print "unbinding setting from active property (currently %s)" % widget.get_active()
                self.settings.unbind(widget,'active')
            else:
                try:
                    print "unbinding setting from value (%s)" % widget.get_value()
                    self.settings.unbind(widget,'value')
                except Exception as e:
                    print repr(e)
    
    def read_local_config(self):
        self.config=ConfigParser()
        if os.path.isfile(self.conffn):
            try:
                self.config.read(self.conffn)
                self.local=self.config.getboolean('Drawer','localset')
                
                if self.local:
                    dbg(self.debug, "using local settings")
                    for key in settings.keys():
                        if not self.config.has_option('Drawer',key.lower()):
                            dbg(self.debug, '%s not present in config file' %key)
                            if settings[key]=='boolean':
                                default=self.settings.get_boolean(key.lower().replace('_','-'))
                            elif settings[key]=='double':
                                default=self.settings.get_double(key.lower().replace('_','-'))
                            elif settings[key]=='int':
                                default=self.settings.get_int(key.lower().replace('_','-'))
                            dbg(self.debug, default)
                            self.config.set('Drawer',key.lower(),str(default))
                        if settings[key]=='int':
                            setattr(self,key,self.config.getint('Drawer',key.lower()))
                        elif settings[key]=='double':
                            setattr(self,key,self.config.getfloat('Drawer',key.lower()))
                        elif settings[key]=='boolean':
                            setattr(self,key,self.config.getboolean('Drawer',key.lower()))
                    #Return True/False to set localset
                    return True
                else:
                    return False
            except Exception as e:
                print "Failed to read %s" %self.conffn
                print repr(e)
                return False
        else:
            return False
    
    def on_iconbutton_clicked(self,widget, data=None):
        dbg(self.debug, "iconbutton activated")
        iconfn=self.filechooser(self.iconfn)
        if iconfn != self.iconfn:
            self.iconfn = iconfn
            pixbuf=GdkPixbuf.Pixbuf.new_from_file(self.iconfn).scale_simple(64,64,GdkPixbuf.InterpType.BILINEAR)
            self.icon.set_from_pixbuf(pixbuf)
            
        
    def on_btn_close_clicked(self, widget, data=None):
        self.name=self.name_entry.get_text()
        if self.local:
            self.save_local_settings()
        return self.iconfn, self.name
        
    def filechooser(self,icon):
        filedialog=Gtk.FileChooserDialog(
            _('Choose an Icon for your Drawer'),
            self,
            Gtk.FileChooserAction.OPEN,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        filedialog.set_filename(icon)
        filter_image= Gtk.FileFilter()
        filter_image.set_name(_("Image Files"))
        filter_image.add_mime_type("image/png")
        filter_image.add_mime_type("image/x-svg")
        filter_image.add_mime_type("image/jpeg")
        filter_image.add_mime_type("image/gif")
        filter_image.add_mime_type("image/bmp")
        filter_image.add_mime_type("image/tiff")
        filter_image.add_mime_type("image/svg+xml")

        filter_any=Gtk.FileFilter()
        filter_any.set_name(_("All files"))
        filter_any.add_pattern('*')
        filedialog.add_filter(filter_image)
        filedialog.add_filter(filter_any)

        response = filedialog.run()
        if response == Gtk.ResponseType.OK:

            newfile=filedialog.get_filename()
            if icon != newfile:
                icon=newfile

        filedialog.destroy()
        return icon
    def on_edit_activate(self, widget, data=None):
        subprocess.Popen(['gedit', self.fn])
        
    def on_btn_reset_clicked(self,widget, data=None):
        if not self.local:
            dbg(self.debug, "reseting global:")
            for key in self.settings.list_keys():
                if key not in ["number-open", "reminder-num"]:
                    dbg(self.debug, "  "+key)
                    self.settings.reset(key)
        else:
            dbg(self.debug, "reseting local to global:")
            self.save_local_settings(reset=True)
            self.bind_local_settings()
            
    def on_keyentry_clicked(self,widget,data=None):
        dbg(self.debug, "reminder key entry clicked")
        key=getText(self,Message=_("Please Enter the key that was sent when you donated"), label=_("Key"))
        dbg(self.debug, "key entered: %s" %key)
        if key != None:
                if key=="2147483647":
                    self.settings.set_int('reminder-num', 2147483647)
                    dbg(self.debug, "Correct key entered")
                    self.donated(True)
                else:
                    dbg(self.debug, "Incorrect key, reminders still enabled")
    
    def donated(self,done=False):
        if done:
            but=self.builder.get_object('keyentry')
            but.set_label(_('Thank you for donating!'))
    
    def on_autostart_toggled(self,widget,data=None):
        if not self.initializing:
            dbg(self.debug, "toggling autostart")
            if os.path.exists(self.autostart):
                os.remove(self.autostart)
                #widget.set_active(False)
                return True
            else:
                as_file=DesktopEntry()
                group={'Type':'Application',
                        'Exec':self.df.get('Exec','Desktop Entry'),
                        'Hidden':'false',
                        'NoDisplay':'false',
                        'X-GNOME-Autostart-enabled':'true',
                        'Name':self.df.get('Name','Desktop Entry')
                        }
                as_file.addGroup('Desktop Entry')
                for key,value in group.items():
                    as_file.set(key,value,'Desktop Entry')
                self.df.write(self.autostart)
                os.chmod(self.autostart, 0754)
                #widget.set_active(True)
                return True
            return False
        
        
            
            
