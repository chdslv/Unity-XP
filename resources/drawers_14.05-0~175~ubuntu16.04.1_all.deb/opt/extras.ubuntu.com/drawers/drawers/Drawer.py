# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2012 Ian Berke ian.berke@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import locale
from locale import gettext as _
locale.textdomain('drawers')
#locale.setlocale(locale.LC_ALL,'es_PR.UTF-8')
#necessary to get import applications to keep their local names
import xdg.Locale
lang=locale.getdefaultlocale()[0]
xdg.Locale.langs=[lang,lang[:2]]

from gi.repository import GLib, GObject, Gtk, Gdk, GdkPixbuf, Gio # pylint: disable=E0611

from xdg.DesktopEntry import DesktopEntry
from math import pi
import cairo, copy
import subprocess, getpass,sys, os,re, shlex
from urllib2 import url2pathname
from ConfigParser import ConfigParser
import logging
logger = logging.getLogger('drawers')
try:
    from gi.repository import Unity
    UNITY=os.environ['XDG_CURRENT_DESKTOP']=='Unity'
except Exception as e:
    print "Unity not loaded"
    print repr(e)
    UNITY=False
    pass
from drawers_lib import Window
from drawers.PreferencesDrawersDialog import PreferencesDrawersDialog
from drawers.EdititemDialog import EdititemDialog
from drawers.DrawersCommon import *
from drawers_lib.helpers import show_uri,  get_help_uri

(TARGET_ENTRY_TEXT, TARGET_ENTRY_PIXBUF) = range(2)
(COLUMN_TEXT, COLUMN_PIXBUF, COLUMN_DISPNAME) = range(3)

UI_INFO = """
<ui>
  <toolbar name='ToolBarL'>
    <toolitem action='TbQuit' />
    <toolitem action='TbPreferences' />
  </toolbar>
  <toolbar name='ToolBarR'>
    <toolitem action='TbAlpha'/>
    <toolitem action='TbPin' />
  </toolbar>
  <popup name='PopupMenu'>
    <menuitem action='EditProps' />
    <menuitem action='DeleteItem' />
    <menuitem action='Help' />
  </popup>
</ui>
"""
#This is a quick hash for icons to associate with file types
#Plan to associate default theme icons with items
icondict={'application':'gtk-about',
            'file':'gtk-file',
            'directory':'folder',
            'image':'gtk-missing-image',
            'inode':'folder',
            'text':'gtk-edit',
            'audio':'media-playback-start',
            'text-html':'text-html',
            'url':'html',
            'video': 'media-playback-start'}

class Drawer(Gtk.Window):
    '''This class will parse a .desktop file and open a Drawer Window with its 
    quicklist contents
    '''
    __gtype_name__ = "Drawer"
    def __init__(self, filename=None, addfile=[],debug=False):
        Gtk.Window.__init__(self)
        self.debug=debug
        dbg(self.debug, "Debugging messages on")
        try:
            dbg(self.debug, "Read config")
            self.localconfig=filename.split('/')[-1].replace('.desktop','.conf')
            self.config=DrawerConfig(self.localconfig)
            self.localset=self.config.LOCALSET
            #self.localset=updateconfig(self.localconfig)
            #writeconfig(self.localconfig,True)
            dbg(self.debug, "Local settings %s" %str(self.localset))
        except Exception as e:
            print repr(e)
        self.set_wmclass('Drawers '+filename.split('/')[-1].replace('.desktop',''),filename)
        self.set_title(filename.split('/')[-1])
        dbg(self.debug, "File: %s" %filename)
        dbg(self.debug, "Addfiles: %s" % '; '.join(addfile))
        self.offset_x = 0
        self.offset_y = 0
        self.pin=False
        self.ordered=False
        self.dragging=False
        self.alpha=None
        self.popupmerge_id=0
        self.theme=Gtk.IconTheme.get_default()
        self.theme.append_search_path('/usr/share/app-install/icons')
        #determine which monitor on multimonitor displays
        screen=self.get_screen()
        self.screenwidth=screen.get_width()
        num_mons = Gdk.Screen.get_n_monitors(screen)
        dbg(self.debug, "Detected %i monitors" %num_mons)
        
        if num_mons >1:

            #get position of mouse; assuming mouse doesn't move off monitor when launcher clicked
            display=Gdk.Display.get_default()
            (scr,x,y,modifier)=display.get_pointer()
            activemon=Gdk.Screen.get_monitor_at_point(screen,x,y)

            rect=Gdk.Screen.get_monitor_geometry(screen,activemon)
            self.offset_x = rect.x
            self.offset_y = rect.y

        self.set_visual(screen.get_rgba_visual())
        
        #Some settings for Unity Launcher and panel bar
        LF_ICONPADDING=10
        PANEL_HEIGHT=24
        self.docked=False
        #Get position (top to bottom) of the opened drawer in Launcher
        if UNITY:
            try:
                self.lf=Unity.LauncherFavorites.get_default().enumerate_ids()
                presentname = [name for name in [filename, filename.split('/')[-1]] if name in self.lf][0]
                if presentname !='':
                    self.lfpos=self.lf.index(presentname)+2
                    self.docked=True
                else: 
                    #set lfpos None so we can anchor to mouse position instead
                    self.docked=False
                    self.lfpos=None
                LF_ICONSIZE=get_icon_size(self.debug)
            except Exception as inst:
                dbg(self.debug, "%s\n%s"%(repr(inst), inst.args))
                self.lfpos=None
        else:
            self.lfpos=None
        #self.docked is not really necessary, but could use in the future for other DEs
        if self.config.LOCALSET and self.config.REMEMBER:
            dbg(self.debug, "Using saved position")
            self.anchorpos_x, self.anchorpos_y=self.config.POSITION
            self.gravity=Gdk.Gravity.NORTH_WEST
        
        elif (self.lfpos==None) or (LF_ICONSIZE==None) or self.docked==False:
            dbg(self.debug, "falling back to mouse position")
            display=Gdk.Display.get_default()
            (scr,x,y,modifier)=display.get_pointer()
            self.anchorpos_y=y
            self.anchorpos_x=x
            self.gravity=Gdk.Gravity.CENTER
            
        else:
            self.anchorpos_y=min([(self.lfpos * (LF_ICONSIZE+LF_ICONPADDING))+PANEL_HEIGHT,screen.get_height()])
            self.anchorpos_x=self.config.MARGIN+self.offset_x
            self.gravity=Gdk.Gravity.WEST
        #Start setting up the drawer with the .desktop file
        if filename != None:  
            self.filename=filename
            try:
                self.df=DesktopEntry(filename) # will parse the .desktop file
                if self.df.hasKey('Actions'):
                    self.actions=self.df.get('Actions', 'Desktop Entry').rstrip(';').split(';')
                    #function to remove duplicates just in case
                    for action in self.actions:
                        if self.actions.count(action)>1: self.actions.remove(action)
                    if self.config.DEADREMOVE: self.deadlinkcheck()
                else:
                    self.actions=[]
                #Required for Unity2D compatibility with drag and drop
                if not self.df.hasKey('MimeType'):
                    dbg(self.debug,"Updating Drawer File to recognize Mimetypes")
                    self.df.set('MimeType','application/*;audio/*;image/*;inode/*;text/*;video/*;','Desktop Entry')
                    
            except Exception as e:
                dbg (self.debug,"Couldn't read desktop file")
                dbg (self.debug,repr(e))
                Gtk.main_quit()
            #Add any items passed to program if it's not in actions already
            for item in addfile:
                if item !=None and item.rstrip('/').split('/')[-1] not in self.actions:
                    add_file(self, item) 
            self.builddrawer()
        
        dbg(self.debug, "number of items: %i" %len(self.actions))
        #connect events
        
        self.connect("delete-event", Gtk.main_quit)
        self.connect("key-press-event", self.handle_keypresses)
        self.connect("key-release-event", self.handle_keyrelease)
        self.connect("enter-notify-event", self.on_mouse_enter)
        self.connect("leave-notify-event", self.on_mouse_leave)
        self.connect("window-state-event", self.on_window_state_change)
        self.focus_handler=self.connect("focus-out-event", lambda widget,event:GLib.timeout_add(100,self.on_focus_out,widget,event))
        
        #Set up dragNdrop to add URIs to open draw
        #self.connect("drag-drop", self.drop_cb)
        self.connect("drag-data-received", self.got_data_cb)
        self.drag_dest_set(Gtk.DestDefaults.ALL, [], Gdk.DragAction.COPY)
        #self.drag_dest_set_target_list(None)
        self.drag_dest_add_uri_targets()
        
        
        #Format the drawer 
        self.set_decorated(False)
        self.set_app_paintable(True)
        self.updatecss()
        self.iconview.get_style_context().add_class('iconview')
        self.scrolledwindow.get_style_context().add_class('iconview')
        self.title.get_style_context().add_class('title')
        self.toolbarL.get_style_context().add_class('title')
        self.toolbarR.get_style_context().add_class('title')
        
        #make popup menu themed like main window
        pwindow=self.popup.get_parent()
        screen=pwindow.get_screen()
        pwindow.set_visual(screen.get_rgba_visual())
        self.popup.get_style_context().add_class('popup')

        #Draw the window and popups with cairo
        self.connect("draw", self.draw_window_cb)
        self.popup.connect('draw', self.draw_window_cb)
        
        #Realize the window
        self.show_all()
        pwindow.queue_draw()
        
        #Put the keyboard focus in the iconview
        self.iconview.grab_focus()
        
        #Don't draw anything until we've moved to the right spot
        gdkwindow=self.get_window()
        if gdkwindow: gdkwindow.freeze_updates()
        
        self.set_gravity(self.gravity)
        self.move(self.anchorpos_x,self.anchorpos_y)
        if gdkwindow: gdkwindow.thaw_updates()
        self.queue_draw()
        if self.config.FIRST_RUN:
            self.on_help_activate(None)
            #self.localset=updateconfig(self.localconfig,False)
            self.config.FIRST_RUN=False
        try:
            remind = (NUM_OPEN % REMINDER_NUM ==0)
        except:
            remind=True
        #self.config.KEY=1
        if remind:
            reminder=getText(self,Message=_("<b>You've opened a Drawer %i times</b>" % NUM_OPEN), 
                        label=_("You will be reminded of this every %i openings"%REMINDER_NUM),
                        Entry=str(REMINDER_NUM),
                        Message2=_('Please consider <a href="%s">donating</a> to receive a key to remove this message'%( DONATE_URL )))
            if reminder != None:
                if reminder=="2147483647":
                    settings.set_int('reminder-num', 2147483647)
        self.hkey=0
        self.hwindow=self.helpoverlay()
        GLib.timeout_add(100, self.reorder)
        GLib.timeout_add(1000,self.color_check)


#Functions
#---------------------------------------------------
    def run(self):
        self.place_items()
        Gtk.main()

    def updatecss(self):
        css = Gtk.CssProvider()
        
        #Want the drawer background and font to change with average of desktop background
        self.BG_rgb= [int(i*self.config.COLOR_SCALING) for i in self.get_color() ]
        if sum(self.BG_rgb)/3 > 175:
            self.FONT_rgb=[50,50,50]
        else:
            self.FONT_rgb=[255,255,255]
        css.load_from_data("""
            .title { background-color: rgba(0, 0, 0, 0); border-width: 0 0 0 0; background-image: None; color: rgba(%s,1);}
            .iconview { background-color: rgba(0, 0, 0, 0); background-image: none; color: rgba(%s,1); font-size:%i; }
            .iconview:selected { background-color: shade(@selected_bg_color, 0.9) ;
            background-image: -gtk-gradient (linear,
                                     left top, right bottom,
                                     from (shade(@selected_bg_color, 1.0)),
                                     to (shade(@selected_bg_color, 0.9)));
                                     color: rgba(%s,1); font-size:%i; }
            .background2 { background-color: rgba(%s,0.7);   color: rgba(%s, 1); }
            .popupbkg { background-color: rgba(0,0,0,0); }
            .popup {background-color: rgba(0,0,0,0); color: rgba(%s, 1); border: 0px rgba(0,0,0,0);  border-radius: 14px; border-width: 0;  }
        """ % ( str(self.FONT_rgb).strip('[]'),
                str(self.FONT_rgb).strip('[]'),self.config.FONTSIZE,
                str(self.FONT_rgb).strip('[]'),self.config.FONTSIZE,
                str(self.BG_rgb).strip('[]'),str(self.FONT_rgb).strip('[]'),
                str(self.FONT_rgb).strip('[]')))
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


    def popupmod(self,name):
        '''Modify the popup to show quicklist items'''
        #First remove any added QL popups and their actions
        if self.popupmerge_id:
            self.uimanager.remove_ui(self.popupmerge_id)
            self.uimanager.remove_action_group(self.uimanager.get_action_groups()[-1])
            self.popupmerge_id=0
        #Get actions and number if there are any
        actiongroup,num=self.quicklist_actiongroup(name)
        if actiongroup != None:
            self.uimanager.insert_action_group(actiongroup)
            #create a ui string with the needed number of items
            ui=self.quicklistui(num)
            #Merge it with popup and save id to remove later
            self.popupmerge_id = self.uimanager.add_ui_from_string(ui)
    
    def quicklistui(self,num):
        '''Create a UI string definition for merging with popup'''
        ui='''
        <popup name='PopupMenu'>
            <separator />
            %s
        </popup>
        '''%('''
            '''.join(["<menuitem action='Quicklist%i' />"%i for i in range(0,num)]))
        return ui
        
    def quicklist_actiongroup(self,name):
        '''Create an Action for each Quicklist item
        and connect it to the execute function '''
        value=0
        actiongroup=False
        if self.df.hasKey('Actions', 'Desktop Action '+name):
            #get the number of actions needed
            value=int(self.df.get('Actions','Desktop Action '+name))
            actiongroup=Gtk.ActionGroup('Quicklist')
            for num in range(0,value):
                #Actions are stored in 'Drawer Action' Groups indexed by number
                label=self.df.get('Name[%i]'%num,'Drawer Action '+name)
                action=Gtk.Action('Quicklist%i'%num,label,None,None)
                #Pass the name of the action and the QL item id(num)
                action.connect('activate',self.quicklist_execute,name,num)
                actiongroup.add_action(action)
            #return actiongroup,value
        if self.config.LOCALSET:
            if not actiongroup:
                actiongroup=Gtk.ActionGroup('Quicklist')
            saveaction=Gtk.Action('Quicklist'+str(value),_('Save state'),None,None)
            saveaction.connect('activate',self.save_state)
            actiongroup.add_action(saveaction)
            value+=1
            if self.config.REMEMBER:
                forgetaction=Gtk.Action('Quicklist'+str(value),_('Forget Saved Position'), None, None)
                forgetaction.connect('activate',self.forget_state)
                actiongroup.add_action(forgetaction)
                value+=1
        if actiongroup:
            return actiongroup, value
        else:
            #if there are no actions return None to skip adding to popup
            return None,None

    def save_state(self, widget):
        self.gravity=Gdk.Gravity.NORTH_WEST
        self.set_gravity(self.gravity)
        x,y = self.get_position()
        self.config.xpos=x
        self.config.ypos=y
        self.config.savelocal()

        if self.pin[0]==self.pindownicon_Above:
            self.config.PINSTATE='PinAbove'
        elif self.pin[0]==self.pindownicon_Below:
            self.config.PINSTATE='PinBelow'
        else:
            self.config.PINSTATE=None
        
        sort=self.alpha[0][0]
        self.config.SORTSTATE=sort
        self.config.savelocal()
    def forget_state(self,widget):
        self.config.xpos=None
        self.config.ypos=None
        self.config.savelocal()
        
    def helpoverlay(self):
        '''Displays a transparent overlay with helpful key shortcuts and info'''
        
        helpwindow=Gtk.Window()
        screen=helpwindow.get_screen()
        helpwindow.set_visual(screen.get_rgba_visual())
        helpwindow.set_decorated(False)
        helpwindow.set_app_paintable(True)
        helpwindow.set_position(Gtk.WindowPosition.CENTER)
        helpwindow.get_style_context().add_class('background2')
        
        #There's a bug that prevents some text in markup from showing if there is no ' '
        
        #Info on Key Presses
        keystrings=[_('<b>Key Shortcuts</b>'),
                    _('       <i>ESC</i> : Quit'),
                    _('       <i>Del</i> or <i>Backspace</i> : Delete selected item'),
                    _('       <i>Enter</i> or <i>Spacebar</i> : Activated selected item'),
                    _('       <i>Arrow keys</i> : Select item'),
                    _('       <i>h</i> : Help'),
                    _('       <i>Numbers 1-9</i> : Launch items 1-9')]
        keybox=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        for line in keystrings:
            keylabel=Gtk.Label()
            keylabel.set_markup(line)
            keylabel.set_alignment(0,0.5)
            keybox.pack_start(keylabel,False,False,1)
        
        #Info on using the Mouse
        mousestring=[_('<b>Mouse Actions</b>'),
        _('       <i>Left click</i> : Open item'),
        _('       <i>Left drag</i> : Reorder'),
        _('       <i>Right click</i> : Popup menu'),
        _('       <i>Left drag title</i> : Move window')]
        mousebox=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        for line in mousestring:
            mouselabel=Gtk.Label()
            mouselabel.set_markup(line)
            mouselabel.set_alignment(0,0.5)
            mousebox.pack_start(mouselabel,False,False,1)        
        
        #Info on what each button in toolbar does
        lines=[_('<b>Toolbar Buttons</b>'),
              (iconpath+'close.svg',_(' : Quit')),
              (iconpath+'preferences.svg',_(' : Preferences')),
              (iconpath+'unsort.svg', _(' : Sort')),
              (iconpath+'pin-up.png', _(' : Pin Window'))]
        iconbox=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        title=Gtk.Label()
        title.set_markup(lines[0])
        title.set_alignment(0,0.5)
        iconbox.pack_start(title,False,False,1)
        for line in lines[1:]:
            hbox=Gtk.Box()
            image=Gtk.Image()
            image.set_from_file(line[0])
            pixbuf=image.get_pixbuf()
            pixbuf=pixbuf.scale_simple(20, 20, GdkPixbuf.InterpType.BILINEAR)
            image.set_from_pixbuf(pixbuf)
            label=Gtk.Label()
            label.set_text(line[1])
            hbox.pack_start(image,False,False,20)
            hbox.pack_start(label,False,False,1)
            iconbox.pack_start(hbox,False,False,0)
            
        footer=_("For more extensive help, go to Preferences->Help")
        footerlabel=Gtk.Label()
        footerlabel.set_text(footer)
        
        #Put all elements on a grid
        grid=Gtk.Grid()
        grid.set_property('margin',20)
        grid.set_column_spacing(30)
        grid.set_row_spacing(20)
        grid.add(mousebox)
        grid.attach_next_to(keybox,mousebox, Gtk.PositionType.RIGHT,1,1)
        grid.attach_next_to(iconbox,mousebox, Gtk.PositionType.BOTTOM,1,1)
        grid.attach_next_to(footerlabel, iconbox,Gtk.PositionType.BOTTOM,2,1)
        helpwindow.add(grid)
        
        #Format everything transparent
        for child in helpwindow.get_children():
            child.set_app_paintable(True)
            child.get_style_context().add_class('iconview')
            child.show()
        helpwindow.connect('draw',self.draw_window_cb)
        #Connect release of the 'h' key with hiding the window
        helpwindow.connect('key-release-event',self.handle_keyrelease)
        return helpwindow

        
    def builddrawer(self):
        """Initializes the contents of the drawer and UI"""
        groups=self.df.groups()
        groups.pop(0) #Don't need the Desktop Entry group
        
        #Main container to put things in
        self.outerbox=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        
        #Create a division in the top section of the outerbox for a title and toolbar
        self.headerbox=Gtk.Box()
        self.outerbox.pack_start(self.headerbox,False,False,1)
        
        #Setup a Toolbar using UI        
        #Create action group for UI
        self.TBaction_group = Gtk.ActionGroup("my_Tbactions")
        action_group=Gtk.ActionGroup("my_PUactions")
        #Toolbar buttons
        #---------------------------
        #The Quit button
        action_quit = Gtk.Action("TbQuit", None, _("Quit"), None)
        self.closebutton=Gio.File.new_for_path(iconpath+'close.svg')
        action_quit.set_gicon(Gio.FileIcon(file=self.closebutton))
        action_quit.connect("activate", self.on_quit_activate)
        self.TBaction_group.add_action(action_quit)

        #The Preferences button
        action_preferences=Gtk.Action("TbPreferences",None,_("Preferences"), None)
        self.prefbutton=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'preferences.svg'))
        action_preferences.set_gicon(self.prefbutton)
        action_preferences.connect("activate", self.on_preferences_activate)
        self.TBaction_group.add_action(action_preferences)
        
        #The Pin or Persistance mode button (icon changes to indicate mode)
        action_pin=Gtk.Action("TbPin", None,_("Pin Window Open"),None)
        self.pinupicon=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'pin-up.png'))
        self.pindownicon_Above=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'pin-downAbove.png'))
        self.pindownicon_Below=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'pin-downBelow.png'))
        self.pin = [self.pinupicon, self.pindownicon_Above,self.pindownicon_Below]
        startstate=self.config.PINSTATE
        if startstate!='None':
            print "cycling-1"
            self.pin.append(self.pin.pop(0))
        if startstate=='PinBelow':
            print "cycling-2"
            self.pin.append(self.pin.pop(0))
        self.on_pin_activate(None,'Just set window')
        action_pin.set_gicon(self.pin[0])
        action_pin.connect("activate", self.on_pin_activate)
        self.TBaction_group.add_action(action_pin)
        
        #The Sort button (icon changes on press to indicate mode)
        action_alphasort=Gtk.Action("TbAlpha", None, _("Sort Alphabetically"), None)
        self.sortAZ=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'sortAZ.svg'))
        self.sortZA=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'sortZA.svg'))
        self.unsort=Gio.FileIcon(file=Gio.File.new_for_path(iconpath+'unsort.svg'))
        self.alpha=[('None',self.unsort),
                    ('AZ',self.sortAZ),
                    ('ZA',self.sortZA)]
        startstate=self.config.SORTSTATE
        while self.alpha[0][0]!=startstate:
            self.alpha.append(self.alpha.pop(0))

        action_alphasort.set_gicon(self.alpha[0][1])
        
        
        action_alphasort.connect("activate", self.on_alpha_activate)
        self.TBaction_group.add_action(action_alphasort)

        #Popup menu items
        #---------------------
        #Edit Properties
        action_editprops = Gtk.Action("EditProps",_("Edit Properties"),None, None)
        action_editprops.connect("activate", self.on_editprops_activate)
        action_group.add_action(action_editprops)

        #Delete Item
        action_delete=Gtk.Action("DeleteItem", _("Delete"), None, None)
        action_delete.connect("activate", self.on_delete_activate)
        action_group.add_action(action_delete)
        
        #Help Item
        action_help = Gtk.Action("Help", _("Help"), None, Gtk.STOCK_HELP)
        action_help.connect("activate", self.on_help_activate)
        action_group.add_action(action_help)
        #-----------------------------
        
        #Setup the User interface (save uimanager reference to modify popups)
        self.uimanager = Gtk.UIManager()
        self.uimanager.insert_action_group(self.TBaction_group)
        self.uimanager.insert_action_group(action_group)
        self.uimanager.add_ui_from_string(UI_INFO)
        self.popup=self.uimanager.get_widget("/PopupMenu")
        self.toolbarL = self.uimanager.get_widget("/ToolBarL")
        self.toolbarL.set_app_paintable(True)
        
        #Setup a TitleBar
        self.title=Gtk.Label(self.df.get('Name', 'Desktop Entry'))
        
        
        self.toolbarR = self.uimanager.get_widget("/ToolBarR")
        self.toolbarR.set_halign(Gtk.Align.END)
        self.toolbarL.set_halign(Gtk.Align.START)
        self.toolbarR.set_app_paintable(True)
        #Get the size needed for the title add to size for icons to get minimum size of drawer
        self.minw=0#self.title.size_request().width# + self.toolbarR.size_request().width+self.toolbarL.size_request().width+96
        self.headerbox.pack_start(self.toolbarL,True,True,0)
        self.titlebox=Gtk.EventBox()

        self.titlebox.connect('button-press-event',self.window_drag)
        self.titlebox.connect('button-release-event', self.window_drag)
        self.titlebox.add(self.title)
        self.titlebox.set_above_child(True)
        self.titlebox.set_visible_window(False)
        self.titlebox.set_size_request(-1, 38)
        self.titlebox.set_halign(Gtk.Align.CENTER)
        self.headerbox.pack_start(self.titlebox,True,True,0)
        self.headerbox.pack_end(self.toolbarR,True,True,0)

        self.toolbarR.set_halign(Gtk.Align.END)
        self.title.set_halign(Gtk.Align.CENTER)
        self.toolbarR.set_show_arrow(False)
        self.toolbarL.set_show_arrow(False)
        
        #Set up a inner container to place iconview and/or buttons if necessary
        self.box=Gtk.Box()
        self.box.set_spacing(5)
        self.iconview=Gtk.IconView()
        self.iconview.set_app_paintable(True)
        
        self.scrolledwindow = Gtk.ScrolledWindow()
        self.scrolledwindow.set_vexpand(True)
        self.scrolledwindow.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scrolledwindow.set_app_paintable(True)
        
        
        #make responsive to events
        self.iconview.add_events(Gdk.EventMask.POINTER_MOTION_MASK)
        self.iconview.add_events(Gdk.EventMask.BUTTON_RELEASE_MASK)
        self.scrolledwindow.add(self.iconview)
        self.box.pack_start(self.scrolledwindow,True,True,5)
        #self.box.pack_start(self.iconview,True,True,5)
        self.iconview.connect("item-activated", self.iv_icon_activated)
        self.iconview.connect("button-release-event", self.on_mouse_click)
        self.iconview.connect("motion-notify-event", self.on_pointer_motion)
        self.iconview.connect("drag-begin", self.on_drag_begin)
        
        #put the item container box inside the outerbox
        self.outerbox.pack_start(self.box,True,True,5)
        self.add(self.outerbox)

        self.queue_draw()
        


    def place_items(self):
        """Clears the iconview model and iterates through a DesktopEntry to repopulate"""
        self.model = Gtk.ListStore(str, GdkPixbuf.Pixbuf, str)
        
        if self.df.hasKey('Actions'):
            self.iconview.freeze_child_notify()
            self.iconview.set_model(None)
            for action in self.actions:
                group='Desktop Action ' + action
                try:
                    if self.df.hasKey('Icon',group):
                        icon=self.df.get('Icon',group)
                        if icon=="":icon=None
                    else:
                        icon=None
                    try:
                        filetype=icondict[self.df.get('Type',group).lower()] #will figure out later how better to map icons to filetype (probably with mimetype)
                    except KeyError:
                        filetype='gtk-file'
                    #add an iconview item or, if not successful, a button
                    if not self.add_iv_item(self.df.get('Name', group), filetype,icon):
                        self.add_but_item(action)
                except KeyError:
                    self.actions.remove(action)
                    pass
             
        #For auto-layout:
        if self.config.AUTO_LAYOUT:
            #global MAXICONS_ROW
            MAXICONS_ROW=int(((self.screenwidth-self.offset_x)-2*self.config.MARGIN)/(self.colwidth()))-1
            if (self.colwidth()*MAXICONS_ROW) > (self.screenwidth-self.config.MARGIN): MAXICONS_ROW-=1
            dbg(self.debug,"Screen Width: %i"% self.screenwidth)
            dbg(self.debug,"Autolayout, Max Icons: %i"%MAXICONS_ROW)
            dbg(self.debug,"Calculated size: %i"%(self.colwidth()*MAXICONS_ROW))
        else:
            #global MAXICONS_ROW
            MAXICONS_ROW=self.config.MAXICONS_ROW
        if len(self.actions)<=MAXICONS_ROW:
            #global MAXICONS_ROW
            MAXICONS_ROW=len(self.actions)
        
        self.iconview.set_text_column(COLUMN_DISPNAME)
        self.iconview.set_pixbuf_column(COLUMN_PIXBUF)
        #if not AUTO_LAYOUT:
        self.iconview.set_columns(MAXICONS_ROW)
        self.iconview.set_column_spacing(self.config.COLUMN_SPACING)
        self.iconview.set_item_width(self.config.ITEM_WIDTH)
        self.iconview.set_model(self.model)
        self.iconview.thaw_child_notify()
        self.model.connect("row-inserted", self.on_model_changed)
        self.iconview.set_reorderable(True)
        #Resize and place window to fit properly
        numrows=(len(self.actions)+1) / (MAXICONS_ROW +1) +1

        if numrows <= 1: numcols=max(1,(len(self.actions)) % (MAXICONS_ROW))
        else: numcols=MAXICONS_ROW
        dbg(self.debug, "Number of columns: %i"%numcols)
        #get approximate number of text rows in longest name (assuming ~10 characters/row)
        #numtitlerows=max(set([len(action) for action in self.actions]))/(CHAR_ROW) +1
        ivrequest=self.iconview.get_preferred_size()[0]
        if numcols < MAXICONS_ROW:
            ivw=numcols*(self.colwidth())+10
        else:
            ivw=ivrequest.width+10
        hb=self.headerbox.size_request()
        
        maxh=Gdk.Screen.height()*4/5
        print maxh
        print ivrequest.height
        h=min(ivrequest.height+hb.height+5,maxh)
        w=max(ivw,self.minw)
        
        dbg(self.debug, "window resizes? %s"%self.get_resizable())
        dbg(self.debug, "resizing %i,%i"%(w,h))
        self.set_size_request(w,h)
        self.resize(w,h)#set_size_request
        dbg(self.debug, "resized")
        #dbg(self.debug, "window size: %i,%i"%(s
        #if self.pin[0]==self.pinupicon:
        #    print "Moving"
        #    self.set_gravity(self.gravity)
        #    self.move(self.anchorpos_x, self.anchorpos_y)

    def colwidth(self):
        if self.config.ICONSIZE*2<self.config.ITEM_WIDTH:
            return self.config.ICONSIZE+self.config.ITEM_WIDTH
        else:
            return 2*self.config.ICONSIZE+10    
    
    def add_iv_item(self, text, icon_name, icon=None):
        pixbuf=None
        try:
            if icon != None:
                try:
                    if '/' in icon:
                        dbg(self.debug, "Loading %s icon from file:%s" %(text,icon))
                        image=Gtk.Image()
                        image.set_from_file(icon)
                        pixbuf=image.get_pixbuf()
                        width, height = pixbuf.get_width(), pixbuf.get_height()
                        if width > height:
                            height = int(height*self.config.ICONSIZE/width)
                            width = self.config.ICONSIZE
                        else:
                            width = int(width*self.config.ICONSIZE/height)
                            height = self.config.ICONSIZE
                        pixbuf = pixbuf.scale_simple(width, height, GdkPixbuf.InterpType.BILINEAR)
                    else:
                        if len(icon) > 4 and icon[-4]=='.': icon=icon[:-4]
                        pixbuf = self.theme.load_icon(icon, self.config.ICONSIZE, 0)
                except Exception as e:
                    dbg(self.debug, "Reading %s failed" %icon)
                    dbg(self.debug, repr(e))
                    pass
                    
                
            if pixbuf==None:
                
                pixbuf = self.theme.load_icon(icon_name, self.config.ICONSIZE, 0)
                if pixbuf == None:
                    dbg(self.debug, "Failed to find an icon in theme for: %s"%icon)
            
            if self.config.LIMIT_TEXT and len(text)>self.config.TEXT_ELLIPS:
                if self.config.TEXT_ELLIPS==0:
                    ellips=''
                else:
                    ellips='...'
                dispname=(text[:self.config.TEXT_ELLIPS-len(ellips)]+ellips)
            else:
                dispname=text
            self.model.append([text, pixbuf, dispname])
            succeed=True
        except:
            succeed=False
            pass
        return succeed

    def add_but_item(self, group):
        
        setattr(self, group+"_button", Gtk.Button(label=group))
        getattr(self, group+"_button").connect("clicked",self.on_button_clicked)
        self.box.pack_start(getattr(self,group+"_button"),False,False,5)
        
    def execute(self, value):            
        """Executes the Exec line of a Desktop Action group"""
        group='Desktop Action '+self.cleanname(value)
        execline=self.df.get("Exec",group)
        if self.df.hasKey("Path",group):
            path=self.df.get("Path",group)
        else:
            path=None
        args=shlex.split(execline)
        subprocess.Popen(args,cwd=path)
        if self.pin[0] == self.pinupicon: self.on_quit_activate(None)
        
    def quicklist_execute(self, widget, name, value):            
        """Executes the Exec line of a Desktop Action group"""
        group='Drawer Action '+self.cleanname(name)
        execline=self.df.get("Exec[%i]"%value,group)
        args=shlex.split(execline)
        subprocess.Popen(args)
        if self.pin[0]!=self.pinupicon: self.on_quit_activate(None)
    
    def delete_selected(self,selection):
        """Takes an action name and removes it from the .desktop file
        and redraws the iconview"""
        self.df.removeGroup('Desktop Action ' + self.cleanname(selection))
        if self.df.hasGroup('Drawer Action ' + self.cleanname(selection)):
            self.df.removeGroup('Drawer Action ' + self.cleanname(selection))
        self.actions.remove(self.cleanname(selection))
        if self.actions !=[]:
            self.df.set('Actions', ';'.join(self.actions)+';','Desktop Entry')
        else:
            self.df.removeKey('Actions','Desktop Entry')
        savedf(self)
        self.place_items()
        
    def warning(self,Message=_("Do you want to Quit?"), Message2=None):
        warningdialog = Gtk.MessageDialog(self, 
                        Gtk. DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT, 
                        Gtk.MessageType.ERROR, 
                        Gtk.ButtonsType.YES_NO, 
                        Message)
        if Message2 != None: warningdialog.format_secondary_text(Message2)
        response=warningdialog.run()
        warningdialog.destroy()
        return response
    
    def resetquicklist(self):
        #reset all actions to be shown in quicklist first
        dbg(self.debug, "Resetting quicklist items")
        for action in self.actions:
            self.df.set('OnlyShowIn','Unity','Desktop Action '+action)
                
    def deadlinkcheck(self):
        """Will cycle through Exec lines and check if any files no longer exist"""
        deadactions=[]
        confirmed=False
        for action in self.actions:
            execline=self.df.get('Exec','Desktop Action '+action)
            fn=execline.replace('xdg-open ','').strip('"')
            if (fn !='') and (fn[0]=='/'):
                exists=False
                for i in range(0,fn.count(' ')+1):
                    
                    if os.path.exists(fn.split(' ',i)[0]):
                        exists=True
                if not exists: deadactions.append(action)
                
        if self.config.DEADCONFIRM and (deadactions!=[]):
            response=self.warning(Message=_('Do you want to remove these dead links?'),Message2=', '.join(deadactions))
            if response==Gtk.ResponseType.YES:
                confirmed=True
        elif self.config.DEADCONFIRM==False:
            confirmed=True
        if confirmed:
            for deadaction in deadactions:
                self.df.removeGroup('Desktop Action '+ deadaction)
                self.actions.remove(deadaction)
                self.df.set('Actions', ';'.join(self.actions)+';', 'Desktop Entry')
    
    def alphareorder(self, rev=False):
        names=[]
        
        if rev==None:
            for index,item in enumerate(self.model):
                names.append((self.actions.index(item[0]),index))
            namesort=sorted(names, key=lambda index:index[0], reverse=False)
            neworder=[index[1] for index in namesort]
        else:
            for index, item in enumerate(self.model):
                names.append((index,item[0]))
            namesort=sorted(names, key=lambda name:name[1].lower(), reverse=rev)
            neworder=[index[0] for index in namesort]
        try:
            newliststore=liststore_reorder(self.model, neworder)
            
        except Exception as e:
            dbg(self.debug, "problem reordering")
            dbg(self.debug, repr(e))
            pass
    def cleanname(self,name):
        for character in BAD_CHARS:
            name=name.replace(character,'')
        return name
        

        
        
#Callbacks
#---------------------------------------------------
    def iv_icon_activated(self, iconview, path):
        iterator = self.model.get_iter(path)
        value=self.model.get_value(iterator,0)
        if value=='Close':
            self.on_quit_activate(None)
        else:
            self.execute(value)

    def on_edit_activate(self, widget, data=None):
        subprocess.Popen(['gedit', self.filename])
        
    def on_preferences_activate(self, widget, data=None):
        pin=self.pin[0]
        self.pin[0]=self.pindownicon_Above
        iconfn=self.df.get('Icon', 'Desktop Entry')
        name=self.df.get('Name', 'Desktop Entry')
        changed=False
        limit_quicklist_old = self.config.LIMIT_QUICKLIST
        response=-1
        
        while response==-1:
            prefwindow=PreferencesDrawersDialog(self.filename,debug=self.debug)
            response=prefwindow.run()
            
        if prefwindow.iconfn != iconfn:
            self.df.set('Icon', prefwindow.iconfn, 'Desktop Entry')
            changed=True
        if prefwindow.name !=name:
            self.df.set('Name', prefwindow.name, 'Desktop Entry')
            self.title.set_text(prefwindow.name)
            changed=True
        if changed==True:
            self.df.write(self.filename)
        prefwindow.destroy()
        self.config.read=self.config.readlocal()
        dbg(self.debug, "ICONSIZE %i"%self.config.ICONSIZE)
        if limit_quicklist_old or self.config.LIMIT_QUICKLIST:
            self.resetquicklist()
        self.updatecss()
        self.place_items()
        self.on_alpha_activate(None,data='No change')
        self.pin[0]=pin
        
    def on_pin_activate(self, widget, data=None):
        if data==None:
            self.pin.append(self.pin.pop(0))
            widget.set_gicon(self.pin[0])
        if self.pin[0]==self.pindownicon_Above:
            self.set_keep_above(True)
            self.set_keep_below(False)
        elif self.pin[0]==self.pindownicon_Below:
            self.set_skip_pager_hint(True)
            self.set_skip_taskbar_hint(True)
            self.stick()
            self.set_keep_above(False)
            self.set_keep_below(True)
            self.unmap()
            self.set_type_hint(Gdk.WindowTypeHint.DOCK)
            self.map()
            
            
        else:
            if self.get_type_hint() != Gdk.WindowTypeHint.NORMAL:
                cur_pos_x, cur_pos_y=self.get_position()
                self.unmap()
                self.set_type_hint(Gdk.WindowTypeHint.NORMAL)
                self.map()
                self.set_skip_pager_hint(False)
                self.set_skip_taskbar_hint(False)
                self.unstick()
                self.set_gravity(self.gravity)
                self.move(cur_pos_x, cur_pos_y)
            self.set_keep_above(False)
            self.set_keep_below(False)
        self.set_gravity(self.gravity)

    
    def on_alpha_activate(self, widget, data='Next'):
        #Unsort-->TimeR-->TimeF-->AZ-->ZA-->Unsort
        if data=='Next':
            #Only move to next sort option if alpha button is clicked (default)
            self.alpha.append(self.alpha.pop(0))
        sort,icon=self.alpha[0]
        if widget !=None:
            #Only change icon if widget is passed!
            widget.set_gicon(icon)
        if sort=='timeF':
            self.alphareorder(rev='timeF')
        elif sort=='timeR':
            self.alphareorder(rev='timeR')
        elif sort=='AZ':
            self.alphareorder()
        elif sort=='ZA':
            self.alphareorder(rev=True)
        elif sort=='None':
            self.alphareorder(rev=None)
        return
        
    def on_editprops_activate(self, widget, data=None):
        selected=self.model[self.iconview.get_selected_items()[0]][0]
        
        entry={}
        entry['Name']=selected
        entry['Actions']={'Names':[],
                          'Execs':[]}
        for key in ['Icon','Exec','OnlyShowIn']:
                entry[key]=self.df.get(key,'Desktop Action '+selected)
        
        if self.df.hasGroup('Drawer Action '+selected):
            print "Has QL"
            for num in range(0,int(self.df.get('Actions','Desktop Action '+selected))):
                entry['Actions']['Names'].append(self.df.get('Name[%i]'%num,'Drawer Action '+selected))
                entry['Actions']['Execs'].append(self.df.get('Exec[%i]'%num,'Drawer Action '+selected))
                print entry['Actions']
        editdialog=EdititemDialog(entry=entry,debug=debug)
        editdialog.debug=self.debug
        response=editdialog.run()
        if response == Gtk.ResponseType.OK:
            dbg(self.debug, "Updating Item Info")
            # need to copy keys and create new group with new action link
            entry['Name']=self.cleanname(entry['Name'])
            entry['Type']=self.df.get('Type','Desktop Action '+selected)
            #only copy to new group if cleaned up name changes
            if entry['Name'] != selected:
                self.df.addGroup('Desktop Action '+ entry['Name'])
                if self.df.hasGroup('Drawer Action ' + selected):
                    self.df.removeGroup('Drawer Action ' + selected)
                dbg(self.debug, "copying group %s to %s"%(selected, entry['Name']))
                self.df.removeGroup('Desktop Action '+selected)
                #replace action in list without changing order
                index=self.actions.index(selected)
                self.actions[index]=entry['Name']
                self.df.set('Actions',';'.join(self.actions)+';','Desktop Entry')
            #copy keys even if some are the same because name has changed
            for key in entry:
                if key == "Actions":
                    num=len(entry["Actions"]["Names"])
                    self.df.set("Actions", num, 'Desktop Action '+entry['Name'])
                    if self.df.hasGroup('Drawer Action ' + entry['Name']):
                        self.df.removeGroup('Drawer Action ' + entry['Name'])
                    if entry['Actions']['Names']!=[]:
                        self.df.addGroup('Drawer Action ' + entry['Name'])
                        for i in range(0,num):
                            self.df.set('Name[%i]'%i,entry['Actions']['Names'][i],'Drawer Action '+entry['Name'])
                            self.df.set('Exec[%i]'%i,entry['Actions']['Execs'][i],'Drawer Action '+entry['Name'])
                else:
                    self.df.set(key, entry[key], 'Desktop Action '+entry['Name'])
            savedf(self)
            self.place_items()
            editdialog.destroy()
        elif response == Gtk.ResponseType.CANCEL:
            editdialog.destroy()
            
    def on_quit_activate(self, widget, data=None):
        dbg(self.debug, "Quitting...")
        try:
            savedf(self)
        except:
            raise
        finally:
            Gtk.main_quit()
    def color_check(self):
        if [int(i*self.config.COLOR_SCALING) for i in self.get_color() ] != self.BG_rgb:
            self.updatecss()
        return True
            
    def get_color (self):
        """Code from Ambiance Chameleon - THANKS! """
        try:
            xprop_value = GLib.spawn_command_line_sync("/usr/bin/xprop -root _GNOME_BACKGROUND_REPRESENTATIVE_COLORS")
            rgb_set = re.match(r".*\((\d+)\,(\d+),(\d+).*", xprop_value[1]).groups ()
            color_hex = '%02x%02x%02x' % (int(rgb_set[0]), int(rgb_set[1]), int(rgb_set[2]))
            return [int(rgb_set[0]), int(rgb_set[1]), int(rgb_set[2])]
        except:
            dbg(self.debug,"No _GNOME_BACKGROUND_REPRESENTATIVE_COLORS xprop found... falling back to black background")
            return [0,0,0]

    def motion_cb(self, wid, context, x, y, time):
        Gdk.drag_status(context,Gdk.DragAction.COPY, time)
        # Returning True which means "I accept this data".
        return True
        
    def got_data_cb(self, wid, context, x, y, data, info, time):
        #Dragging desktop files from Dash gives uri not text!
        if 'uri-list' in data.get_data_type().name():
            dbg(self.debug,"adding uris")
            files=data.get_uris()
        else:
            dbg(self.debug, "adding text")
            files=data.get_text().rstrip('\n').split('\n')
        dbg(self.debug, str(files))
        for fn in files:
                add_file(self,fn.replace('file://',''))
        self.place_items()
        context.finish(True, False, time)
    def window_drag(self, widget, data):
        self.begin_move_drag(1, data.x_root, data.y_root, data.time)
        self.dragging=True
        return True

    def on_button_clicked(self,widget, data=None):
        label=widget.get_label()
        if label == "Close":
            self.on_quit_activate(None)
            
        else:
            self.execute(label)
    
    def responseToDialog(self,entry, dialog, response):
        dialog.response(response)
    def draw_window_cb(self, widget, cr):

        #clear everything before we start painting
        cr.set_source_rgba(0,0,0,0)
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.paint()
        w = Gtk.Widget.get_allocated_width(widget)
        h = Gtk.Widget.get_allocated_height(widget)
        offset=0
        radius=10
        
        
        
        r=float(self.BG_rgb[0])/255.
        g=float(self.BG_rgb[1])/255.
        b=float(self.BG_rgb[2])/255.

        fr=float(self.FONT_rgb[0])/255.
        fg=float(self.FONT_rgb[1])/255.
        fb=float(self.FONT_rgb[2])/255.
        rgba_hl=(1.0,1.0,1.0,0.05)
        if self.config.BORDER:
            offset=2
            area = (offset, w-offset, offset, h-offset)
            draw_rounded(cr, area, radius)
            cr.set_source_rgba(fr,fg,fb,1)
            cr.set_line_width(1)
            cr.stroke()


        area = (offset, w-offset, offset, h-offset)

        draw_rounded(cr, area, radius)
        cr.set_source_rgba(r,g,b,self.config.TRANSPARENCY)
        cr.fill_preserve()
        cr.set_operator(cairo.OPERATOR_OVER)
        dots_surf = cairo.ImageSurface (cairo.FORMAT_ARGB32, 4, 4)
        dots_cr= cairo.Context(dots_surf)
        dots_cr.set_operator (cairo.OPERATOR_CLEAR)
        dots_cr.paint ()
        dots_cr.scale (1.0, 1.0)
        dots_cr.set_operator (cairo.OPERATOR_OVER)
        dots_cr.set_source_rgba(rgba_hl[0],
                                rgba_hl[1],
                                rgba_hl[2],
                                rgba_hl[3])
        dots_cr.rectangle (0, 0, 1, 1)
        dots_cr.fill ()
        dots_cr.rectangle (2, 2, 1, 1)
        dots_cr.fill ()
        dots_pattern = cairo.SurfacePattern (dots_surf)
        cr.set_source (dots_pattern)
        dots_pattern.set_extend (cairo.EXTEND_REPEAT)
        cr.fill_preserve() 
        hl_x,hl_y=w/2, 0
        hl_size=2*h/3
        hl_pattern = cairo.RadialGradient(hl_x,
                                         0,
                                         0,
                                         hl_x,
                                         0,
                                         hl_size)
        hl_pattern.add_color_stop_rgba( 0.0,
                                        rgba_hl[0],
                                        rgba_hl[1],
                                        rgba_hl[2],
                                        rgba_hl[3]*4)
        hl_pattern.add_color_stop_rgba(1.0,1.0,1.0,1.0,0)
        cr.set_source(hl_pattern)
        cr.fill()
        cr.set_operator(cairo.OPERATOR_OVER)
        
    def handle_keypresses(self,widget,event,data=None):
        item=None
        dbg(self.debug, "key press detected: %i"%event.keyval)
        if event.keyval == 65307:  #ESC key
            self.on_quit_activate(None)
        elif self.iconview.get_selected_items() != [] and (event.keyval == 65288 or event.keyval== 65535): #delete or backspace keys
            selected_name=self.model[self.iconview.get_selected_items()[0]][0]
            self.delete_selected(selected_name)
            
        shortcuts={ Gdk.KEY_1: 0,
                    Gdk.KEY_2: 1,
                    Gdk.KEY_3: 2,
                    Gdk.KEY_4: 3,
                    Gdk.KEY_5: 4,
                    Gdk.KEY_6: 5,
                    Gdk.KEY_7: 6,
                    Gdk.KEY_8: 7,
                    Gdk.KEY_9: 8,
                    Gdk.KEY_KP_1: 0,
                    Gdk.KEY_KP_2: 1,
                    Gdk.KEY_KP_3: 2,
                    Gdk.KEY_KP_4: 3,
                    Gdk.KEY_KP_5: 4,
                    Gdk.KEY_KP_6: 5,
                    Gdk.KEY_KP_7: 6,
                    Gdk.KEY_KP_8: 7,
                    Gdk.KEY_KP_9: 8}
        if event.keyval in shortcuts.keys():
            try:
                item=self.model[shortcuts[event.keyval]][0]
                dbg(self.debug, "Executing %s"%item)
                self.execute(item)
            except Exception as e:
                dbg(self.debug, "Problem using key shortcut execution")
                dbg(self.debug, repr(e))
                pass
        #if (event.keyval == Gdk.KEY_h or event.keyval==Gdk.KEY_H):
        #    self.on_help_activate(None)
        if event.keyval==Gdk.KEY_h or event.keyval==Gdk.KEY_H:
            self.hkey+=1
            if self.hkey>0: self.hwindow.show_all()
            
    def handle_keyrelease(self,widget,event,data=None):
        if event.keyval == Gdk.KEY_h or event.keyval==Gdk.KEY_H:
            self.hkey=0
            self.hwindow.destroy()
            self.hwindow=self.helpoverlay()
        pass

    def on_mouse_click(self,widget, event):
        # Check if right mouse button was preseed
        if event.type == Gdk.EventType.BUTTON_RELEASE and self.dragging==False:
            try:
                path=self.iconview.get_selected_items()[0]
            except:
                path=None
                pass
            if event.button == 3 and path != None:
                iterator = self.model.get_iter(path)
                value=self.model.get_value(iterator,0)
                self.popupmod(value)
                self.popup.popup(None, None, None, None, event.button, event.time)
            if event.button == 1 and path !=None:
                self.iv_icon_activated(widget, path)
        elif event.type == Gdk.EventType.BUTTON_RELEASE and self.dragging==True:
            self.dragging=False


    def on_drag_begin(self,widget, data):
        self.dragging=True
    
    def on_help_activate(self,widget,data=None):
        """open up help dialog"""
        helpdialog = Gtk.MessageDialog(self, 
                        Gtk. DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT, 
                        Gtk.MessageType.INFO, 
                        Gtk.ButtonsType.OK, 
                        _("Help for Drawers"))
        helpstring=_("""
To use a <b>Drawer</b>, just drag and drop files, directories, urls, etc. to the launcher or the open drawer window.

- <i><u>Single</u> <b>Left-click</b></i> items to launch them (via it's default application if required).

- <i><u>Single</u> <b>Right-click</b></i> to edit their properties, delete them, or launch them via alternate actions (set in properties)

- Hold the <u>Left</u> mouse button to drag icons and reorder the drawer, or use the Sort button in the toolbar to alphabetically sort

- Press and hold the <b>h</b> key for quick help

- Pressing <i>ESC</i> exits the drawer. 

- Keys 1-9 are shortcuts to execute the first 9 items in the drawer.

- Pressing the <i>Pin</i> button makes the Drawer stay open and on top for multiple executions

- You can edit the Drawer preferences, such as its name or icon by pressing the <i>Preferences</i> icon in the toolbar.

For more extensive help, press the <i>Help</i> button in preferences

If you like Drawers, please consider <a href="%s"> Donating </a>
        """ % DONATE_URL)
        helpdialog.format_secondary_markup(helpstring)
        helpdialog.set_position(Gtk.WindowPosition.CENTER)
        screen=helpdialog.get_screen()
        helpdialog.set_visual(screen.get_rgba_visual())

        helpdialog.set_decorated(False)
        helpdialog.get_style_context().add_class('background2')
        helpdialog.set_app_paintable(True)

        messagearea=helpdialog.get_message_area()
        messagearea.get_style_context().add_class('iconview')
        messagearea.set_app_paintable(True)
        helpdialog.connect("draw", self.draw_window_cb)
        helpdialog.add_button("More Help", Gtk.ResponseType.HELP)
        response=helpdialog.run()
        helpdialog.destroy()
        if response==Gtk.ResponseType.HELP:
            show_uri(self, "ghelp:%s" % get_help_uri('index'))
        return response

    def on_delete_activate(self, widget, data=None):
        if self.iconview.get_selected_items() != []:
            selected_name=self.model[self.iconview.get_selected_items()[0]][0]
            self.delete_selected(selected_name)
    
    def on_window_state_change(self, widget, state, data=None):
        if state.new_window_state == Gdk.WindowState.ICONIFIED and self.config.FOCUS_REQ:
            dbg(self.debug, "minimized so exitting")
            self.on_quit_activate(None)
        
    
    def on_focus_out(self,widget,event,data=None):  
        if self.config.FOCUS_REQ and self.pin[0]==self.pinupicon and not self.dragging:
            toplevels=self.list_toplevels()
            if not any([level.is_active() for level in toplevels][1:]):
                dbg(self.debug,"Lost focus so quitting")
                self.on_quit_activate(None)
        if self.dragging: self.dragging=False
        return False
            
    def on_pointer_motion(self, widget, event):
        path= self.iconview.get_path_at_pos(event.x, event.y)
        if path !=None:
                self.iconview.select_path(path)
        if path == None:
            self.iconview.unselect_all()
    def on_model_changed(self, liststore,treepath, treeiter):
        self.ordered=True
        pass
    
    def on_mouse_enter(self, widget, data=None):
        self.TBaction_group.set_visible(True)
        self.present()
    
    def on_mouse_leave(self, widget, data=None):
        if self.config.HIDE_BUTTONS:
            if data.detail != Gdk.NotifyType.INFERIOR:
                self.TBaction_group.set_visible(False)
        
        
    def reorder(self):
        #print "main self:%s,    self.helpoverlay: %s,   self.pwindow: %s"%( self.is_active(), self.hwindow.is_active(),self.pwindow.is_active())
        
        if self.ordered:
            newactions=[]
            for row in range(0,len(self.model)):
                newactions.append(self.cleanname(self.model[row][0]))
            self.df.set('Actions', ';'.join(newactions)+';','Desktop Entry')
            self.actions=newactions
            savedf(self)
            self.ordered=False
        return True
        
def draw_rounded(cr, area, radius):
    """ draws rectangles with rounded (circular arc) corners """
    a,b,c,d=area
    cr.arc(a + radius, c + radius, radius, 2*(pi/2), 3*(pi/2))
    cr.arc(b - radius, c + radius, radius, 3*(pi/2), 4*(pi/2))
    cr.arc(b - radius, d - radius, radius, 0*(pi/2), 1*(pi/2))  # ;o)
    cr.arc(a + radius, d - radius, radius, 1*(pi/2), 2*(pi/2))
    cr.close_path()

def liststore_reorder(liststore, neworder):
    """Reorders a Gtk.ListStore by swapping row at listindex with row at listvalue"""
    try:
        x=range(0,len(neworder))
        for i in x:
            #print liststore[i][0] + '-->' + liststore[neworder[i]][0]
            liststore.swap(liststore.get_iter(neworder[i]),liststore.get_iter(i))
            temp=neworder[neworder.index(i)]
            neworder[neworder.index(i)]=neworder[i]
            neworder[i]=temp
        return liststore
    except Exception as e:
        return e

