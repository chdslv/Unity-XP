# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2012 Ian Berke ian.berke@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import optparse
import sys,os


from gi.repository import Gtk, Gdk,GLib, GObject # pylint: disable=E0611

from drawers import DrawersWindow
from drawers import Drawer
from drawers import DrawerFolder
from drawers import QuerynameDialog
from drawers import DrawerApp

from drawers_lib import set_up_logging, get_version

def parse_options():
    """Support for command line options"""
    parser = optparse.OptionParser(version="%%prog %s" % get_version())
    parser.add_option(
        "-v", "--verbose", action="count", dest="verbose")
    parser.add_option(
        "-a", "--active", action="store_true", dest="active", default=False)
    parser.add_option(
        "-m", "--menu", action="store_true", dest="menu", default=False)
    parser.add_option(
        "-d", "--debug", action="store_true", dest="debug", default=False)
        #help=_("Show debug messages (-vv debugs drawers_lib also)"))
    parser.add_option(
        "-f", "--file", action="store", type="string", dest="filename", default=None)


    (options, args) = parser.parse_args()

    set_up_logging(options)
    return options

def main():
    'constructor for your class instances'
    options=parse_options()
    filename=options.filename
    debug=options.debug
    active=options.active
    menu=options.menu
    #remove all arguments
    addfile=sys.argv[1:]
    args=['-a','--active','--file','-f','-d','--debug','-v',filename,'-m','--menu']
    for arg in args:
        try:
            addfile.remove(arg)
        except:
            pass
            
    if filename!= None and not os.path.exists(filename):
        filename=None
    go(filename,addfile,debug,active,menu)
    
def go(filename,addfile,debug,active,menu):
    # Run the application. 
    if filename != None and not (active or menu):   
        window = Drawer.Drawer(filename, addfile, debug)
    elif filename != None and active:
        window = DrawerFolder.DrawerFolder(filename,addfile,debug)
    elif menu:
        window = DrawerApp.DrawerApp(filename,addfile,debug=debug)
    else:
        window = DrawersWindow.DrawersWindow()
        window.debug=debug
        if addfile != []:
            for fn in addfile:
                window.add_file(fn)
    window.show()
    window.run()


    
