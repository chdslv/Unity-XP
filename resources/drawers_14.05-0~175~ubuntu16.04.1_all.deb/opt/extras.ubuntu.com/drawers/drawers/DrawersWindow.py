# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2012 Ian Berke ian.berke@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import locale
from locale import gettext as _
locale.textdomain('drawers')

from gi.repository import Gtk, Gio # pylint: disable=E0611
from xdg.DesktopEntry import DesktopEntry
from xdg.Mime import get_type

import logging, getpass, os

logger = logging.getLogger('drawers')

from drawers_lib import Window
from drawers.AboutDrawersDialog import AboutDrawersDialog
from drawers.PreferencesDrawersDialog import PreferencesDrawersDialog
from drawers.DrawersCommon import *

# See drawers_lib.Window.py for more details about how this class works


class DrawersWindow(Window):
    __gtype_name__ = "DrawersWindow"

    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(DrawersWindow, self).finish_initializing(builder)
        
        try:
            self.unity_launcher = UnityLauncher()
        except:
            self.unity_launcher = None
            print "no Unity found"
            pass

        self.config = DrawerConfig()
        self.AboutDialog = AboutDrawersDialog
        prefbutton=self.builder.get_object("mnu_preferences")
        prefbutton.connect("activate",self.on_preferences_activate)
        createbutton=self.builder.get_object("CreateButton")
        createbutton.connect("clicked",self.newdrawer)
        activebutton=self.builder.get_object("ActiveButton")
        activebutton.connect("clicked",self.activedrawer)
        categorybutton=self.builder.get_object("CategoryButton")
        categorybutton.connect("clicked",self.appmenudrawer)
        # Code for other initialization actions should be added here.
        self.command='/opt/extras.ubuntu.com/drawers/bin/drawers'
        self.icon='/opt/extras.ubuntu.com/drawers/share/drawers/media/drawers.svg'
    def run(self):
        Gtk.main()
        
    def newdrawer(self,data):
        badname=True
        
        while badname:
            self.name=self.getText()
            if self.name == -1:
                return
            fn=self.name.strip()+'.desktop'
            newfile='/home/'+user+'/.local/share/applications/'+fn
            if os.path.isfile(newfile):
                check=self.warning(_("A drawer with that name exists"), _("Do you want to <i>overwrite</i>?"))
                if check==Gtk.ResponseType.YES:
                    badname=False
            else: badname=False
        

        #should make this be determined independently probably using os module
        groupentry={'Name':self.name,
            'Exec':self.command+ ' --file "'+newfile+ '" %U',
            'Type':'Application',
            'Icon':self.icon,
            'MimeType':'application/*;audio/*;image/*;inode/*;text/*;video/*;',
            'StartupWMClass':'Drawers '+self.name
            }
        self.createlauncher(newfile,groupentry)
        self.filename=newfile
        self.actions=[]
        
        self.on_preferences_activate(None)
        
        if self.unity_launcher != None:
            self.unity_launcher.add(fn)

        messagelabel=self.builder.get_object("label1")
        messagelabel.set_markup(_("""
Your Drawer has been created and added to the Unity Launcher!
To start using it, drag and drop from a file manager, web browser or the Unity Dash:
    - Files
    - Applications
    - Folders
    - URLs
Onto the Launcher or the open Drawer""" ))
    def activedrawer(self,widget):
        '''create active drawer launcher file'''
        #Function to choose a path
        filedialog=Gtk.FileChooserDialog(
            _('Choose a Folder for your Active Drawer'),
            self,
            Gtk.FileChooserAction.SELECT_FOLDER,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        #Add Filter to only show/choose directories
        filter_folder= Gtk.FileFilter()
        filter_folder.set_name("Folders")
        filter_folder.add_mime_type("inode/directory")
        filedialog.add_filter(filter_folder)

        #Function to write launcher, pass the path, create custom config and set by default
        path=None
        response=filedialog.run()
        
        if response == Gtk.ResponseType.OK:

            path=filedialog.get_filename()
            
            dbg(self.debug, "Chose %s"% path)
        filedialog.destroy()
        if path==None:
            return
        #Write 
        self.name=path.split('/')[-1]
        fn=self.name+'.desktop'
        newfile='/home/'+user+'/.local/share/applications/'+fn
        self.icon='folder'
        groupentry={'Name':self.name,
            'Exec':self.command+ ' -a --file "'+newfile+ '" %U',
            'Type':'Application',
            'Path':path,
            'Icon':self.icon,
            'MimeType':'application/*;audio/*;image/*;inode/*;text/*;video/*;',
            'StartupWMClass':'Drawers '+self.name
            }
        
        self.createlauncher(newfile, groupentry)
        self.filename=newfile
        self.actions=[]
        
        self.on_preferences_activate(None)
        
        if self.unity_launcher != None:
            self.unity_launcher.add(fn)

        messagelabel=self.builder.get_object("label1")
        messagelabel.set_markup(_("""
An Active Drawer has been created and added to the Unity Launcher!
This drawer is like a folder view of non-hidden items in a specific folder.
Dropping items on the Launcher will copy them to the folder.
Deleting items will <b>delete them from folder</b>.
Open drawer can be pinned below windows on the desktop.
Launcher maintains a quicklist of 10 most recent items in drawer (at last opening).
Items can also be pinned to quicklist by right clicking them in open drawer.""" ))

    def createlauncher(self,newfile,groupentry):
        self.df=DesktopEntry()
        group='Desktop Entry'
        
        self.df.addGroup(group)
        self.actions=[]
        self.filename=newfile
        for key in groupentry:
            self.df.set(key,groupentry[key],group)
        self.df.write(newfile)
        os.chmod(newfile, 0754)
        return True
        
    def get_mimetype(self,path):
        mime=get_type(path)
        return str(mime).split('/')[0]

    def responseToDialog(self,entry, dialog, response):
        dialog.response(response)
    def getText(self,):
        #base this on a message dialog
        dialog = Gtk.MessageDialog(
            self,
            1,
            Gtk.MessageType.QUESTION,
            Gtk.ButtonsType.OK_CANCEL,
            None)
        dialog.set_markup(_('Please enter a <b>name</b> for your drawer:'))
        #create the text input field
        entry = Gtk.Entry()
        #allow the user to press enter to do ok
        entry.connect("activate", self.responseToDialog, dialog, Gtk.ResponseType.OK)
        #create a horizontal box to pack the entry and a label
        hbox = Gtk.HBox()
        hbox.pack_start(Gtk.Label(_("Name:")), False, 5, 5)
        hbox.pack_end(entry,True,True,0)
        #some secondary text
        #dialog.format_secondary_markup("This will be used for <i>identification</i> purposes")
        #add it and show it
        dialog.vbox.pack_end(hbox, True, True, 0)
        dialog.show_all()
        #go go go
        response=None
        
        while response != Gtk.ResponseType.OK:
            response = dialog.run()
            if response == Gtk.ResponseType.CANCEL:
                    dialog.destroy()
                    return -1
            text=entry.get_text()
            if ('[' in text) or (']' in text):
                erresponse=self.errormsg(_("Name has invalid characters"),_("Names can NOT contain: '[' or ']' characters"))
                response=None
            
        dialog.destroy()
        return text

    def warning(self,Message=_("Do you want to Quit?"), Message2=None):
        warningdialog = Gtk.MessageDialog(self, 
                        Gtk. DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT, 
                        Gtk.MessageType.ERROR, 
                        Gtk.ButtonsType.YES_NO, 
                        Message)
        if Message2 != None: warningdialog.format_secondary_markup(Message2)
        response=warningdialog.run()
        warningdialog.destroy()
        return response
        
    def errormsg(self,Message=_("Error"), Message2=None):
        warningdialog = Gtk.MessageDialog(self, 
                        Gtk. DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT, 
                        Gtk.MessageType.ERROR, 
                        Gtk.ButtonsType.OK, 
                        Message)
        if Message2 != None: warningdialog.format_secondary_markup(Message2)
        response=warningdialog.run()
        warningdialog.destroy()
        return response
    
    def on_preferences_activate(self, widget, data=None):
        iconfn=self.icon
        name=self.name
        changed=False
        response=-1
        while response==-1:
            prefwindow=PreferencesDrawersDialog(self.filename)
            response=prefwindow.run()

        if prefwindow.iconfn != iconfn:
            self.df.set('Icon', prefwindow.iconfn, 'Desktop Entry')
            changed=True
        if prefwindow.name !=name:
            self.df.set('Name', prefwindow.name, 'Desktop Entry')
            self.set_title(prefwindow.name)
            changed=True
        if changed==True:
            self.df.write(self.filename)
        prefwindow.destroy()
    
    def appmenudrawer(self, widget):
        
        newfile='/home/'+USER+'/.local/share/applications/Applications.desktop'
        execline=\
            '/opt/extras.ubuntu.com/drawers/bin/drawers -m "applications.menu" -f "%s"'\
            %(newfile)
        name='Applications'
        icon=iconpath+'apps.svg'
        groupentry={'Name':name,
                    'Exec':execline,
                    'Actions':'',
                    'Type':'Application',
                    'Icon':icon,
                    'StartupWMClass':'Drawers '+name}
        self.createlauncher(newfile,groupentry)
        self.filename=newfile
        self.name=name
        self.actions=[]
        
        self.on_preferences_activate(None)
        
        if self.unity_launcher != None:
            self.unity_launcher.add(newfile)

        messagelabel=self.builder.get_object("label1")
        messagelabel.set_markup(_("""

Your AppMenu Drawer has been created and added to the Unity Launcher!
To create a drawer for just one category, right click on that category and select the appropriate menu option. 
AppMenu Drawer contents and categories can be edited using any menu editing software (e.g. alacarte, menulibre)
""" ))

    def categorysearch(self, widget):
        dialog = Gtk.MessageDialog(
            self,
            1,
            Gtk.MessageType.QUESTION,
            Gtk.ButtonsType.OK_CANCEL,
            None)
        dialog.set_markup(_('Enter a <b>Category</b> of applications for your drawer:'))
        dialog.format_secondary_markup(_("<i>Examples</i>: Graphics, Network, WebBrowser, Audio, Video, Game"))
        #create the text input field
        entry = Gtk.Entry()
        #allow the user to press enter to do ok
        entry.connect("activate", self.responseToDialog, dialog, Gtk.ResponseType.OK)
        #create a horizontal box to pack the entry and a label
        hbox = Gtk.HBox()
        hbox.pack_start(Gtk.Label(_("Category:")), False, 5, 5)
        hbox.pack_end(entry,True,True,0)
        
        dialog.vbox.pack_end(hbox, True, True, 0)
        dialog.show_all()
        #go go go
        response=None
        
        while response != Gtk.ResponseType.OK:
            response = dialog.run()
            if response == Gtk.ResponseType.CANCEL:
                    dialog.destroy()
                    return -1
            text=entry.get_text()
            dialog.destroy()
        if text!='':
            dbg(self.debug, "searching for %s"%text.strip())
            files=self.category_query(text.strip())
        self.name=text.strip()
        fn=self.name+'.desktop'
        self.icon='/opt/extras.ubuntu.com/drawers/share/drawers/media/drawers.svg'
        newfile=BASENAME+'/.local/share/applications/'+fn
        groupentry={'Name':self.name,
            'Exec':self.command+ ' --file "'+newfile+ '" %U',
            'Type':'Application',
            'Icon':self.icon,
            'MimeType':'application/*;audio/*;image/*;inode/*;text/*;video/*;',
            'StartupWMClass':'Drawers '+self.name
            }
        self.createlauncher(newfile, groupentry)
        for app in files:
            add_file(self,app)
        
        self.on_preferences_activate(None)

        if self.unity_launcher != None:
            self.unity_launcher.add(fn)        
        
        messagelabel=self.builder.get_object("label1")
        messagelabel.set_markup(_("""
Your Drawer has been created and added to the Unity Launcher! 
                
To further fill it, drag and drop from a file manager, web browser or the Unity Dash:
    - Files
    - Applications
    - Folders
    - URLs
Onto the Launcher or the open Drawer""" ))

    def category_query(self,search):
        results=[]
        print search
        try:
            for searchpath in SEARCH_DIRS:
                print "Searching in %s" %searchpath
                for fn in os.listdir(searchpath):
                    if fn.split('.')[-1] == 'desktop':
                        deskfile=DesktopEntry(searchpath+'/'+fn)
                        result = None
                        if deskfile.hasKey('Categories'):
                            try:
                                if search.lower() in deskfile.get('Categories','Desktop Entry').lower():
                                    results.append(searchpath+'/'+fn)
                            except Exception as e:
                                print repr(e)
                                pass
            dbg(self.debug, "Adding: %s"% '/n        '.join([result.split('/')[-1] for result in results]))
            return results
        except Exception as e:
            print repr(e)
            return []
