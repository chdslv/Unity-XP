# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2012 Ian Berke ian.berke@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from gi.repository import Gtk,Gdk # pylint: disable=E0611

from drawers_lib.helpers import get_builder
from drawers.DrawersCommon import dbg

import gettext
from gettext import gettext as _
gettext.textdomain('drawers')

import os

class EdititemDialog(Gtk.Dialog):
    __gtype_name__ = "EdititemDialog"

    def __new__(cls,entry={},debug=False):
        """Special static method that's automatically called by Python when 
        constructing a new instance of this class.
        
        Returns a fully instantiated EdititemDialog object.
        """
        builder = get_builder('EdititemDialog')
        new_object = builder.get_object('edititem_dialog')
        cls.entry=entry
        cls.debug=debug
        #super(EdititemDialog,cls).__new__(cls)
        new_object.finish_initializing(builder,entry)
        return new_object

    def finish_initializing(self, builder, entry):
        """Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a EdititemDialog object with it in order to
        finish initializing the start of the new EdititemDialog
        instance.
        """
        # Get a reference to the builder and set up the signals.
        self.entry=entry
        self.builder = builder
        self.ui = builder.get_ui(self)
        self.theme=Gtk.IconTheme.get_default()
        self.theme.append_search_path('/usr/share/app-install/icons')
        
        self.icon=Gtk.Image()
        #Need to determine whether icon is a path or part of theme or not set.
        self.seticon()
        self.iconbutton = self.builder.get_object('iconbutton')
        self.iconbutton.add(self.icon)
        
        self.nameentry=self.builder.get_object('name')
        self.nameentry.set_text(self.entry['Name'])
        
        self.execentry=self.builder.get_object('exec')
        self.execentry.set_text(self.entry['Exec'])
        
        self.quicklist=self.builder.get_object('quicklist')
        self.quicklist.set_active(self.entry['OnlyShowIn']=='Unity')
        
        self.quicklistitemarea=self.builder.get_object('QLitemarea')
        self.addQLbutton=self.builder.get_object('addQLbutton')
        icon=Gtk.Image.new_from_stock(Gtk.STOCK_ADD, Gtk.IconSize.MENU)
        icon.show()
        self.addQLbutton.add(icon)
        self.QLname_entries=[]
        self.QLexec_entries=[]
        for num in range(0,len(self.entry['Actions']['Names'])):
            label=self.entry['Actions']['Names'][num]
            execline=self.entry['Actions']['Execs'][num]
            self.on_addQLbutton_clicked(None,label,execline,num)
    
    def on_addQLbutton_clicked(self,widget,label='',execline='',num=None):
        if num == None:
            if self.QLname_entries==[]:
                num=0
            else:
                num = max([tup[0] for tup in self.QLname_entries])+1
        labelentry=Gtk.Entry(text=label)
        execentry=Gtk.Entry(text=execline)
        labelentry.show()
        execentry.show()
        self.QLname_entries.append([num,labelentry])
        self.QLexec_entries.append(execentry)
        DeleteButton=Gtk.Button(None)
        icon=Gtk.Image.new_from_stock(Gtk.STOCK_REMOVE,Gtk.IconSize.MENU)
        icon.show()
        DeleteButton.add(icon)
        DeleteButton.connect('clicked', self.on_QLdelete_activate, num)
        DeleteButton.show()
        
        box=Gtk.Box(orientation = Gtk.Orientation.HORIZONTAL)
        box.pack_start(labelentry,False,False,0)
        box.pack_start(execentry,True,True,0)
        box.pack_start(DeleteButton,False,False,0)
        box.show()
        dbg(self.debug, "Packing %i, %s" %(num,label))
        self.quicklistitemarea.pack_start(box,True,True,0)
    
    def on_QLdelete_activate(self,widget,num):
        dbg(self.debug, "Deleting %i"%num)
        children=self.quicklistitemarea.get_children()
        index=[val for (val,widget) in self.QLname_entries].index(num)
        if children[index+1] != self.addQLbutton:
            self.quicklistitemarea.remove(children[index+1])
            self.QLname_entries.pop(index)
            self.QLexec_entries.pop(index)

        
        
    def seticon(self):
        '''function to set the icon to whatever is in self.entry['icon']'''
        if os.path.exists(self.entry['Icon']):
            self.icon.set_from_file(self.entry['Icon'])
        else:
            self.icon.set_from_icon_name(self.entry['Icon'],Gtk.IconSize.BUTTON)
        self.icon.show()

        pass
    
    def on_iconbutton_clicked(self,widget,data=None):
        iconfn=self.filechooser(self.entry['Icon'])
        iconpth=iconfn.rsplit('/',1)[0]
        icon=iconfn.split('/')[-1].split('.')[0]
        if (iconfn != self.entry['Icon']) and (icon != self.entry['Icon']):
            if iconpth in self.theme.get_search_path():
                self.entry['Icon'] = icon
                dbg(self.debug, "changing icon to %s" %icon)
            else:
                self.entry['Icon']= iconfn
                dbg(self.debug, "changing icon to %s" %iconfn)
            self.seticon()
            
    def filechooser(self,icon):
        filedialog=Gtk.FileChooserDialog(
            _('Choose an Icon for your Drawer'),
            self,
            Gtk.FileChooserAction.OPEN,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        if not os.path.exists(icon):
            icon=self.theme.lookup_icon(icon, Gtk.IconSize.BUTTON, 0)
            if icon != None:
                icon = icon.get_filename()
        if icon == '' or icon == None:
            icon='/usr/share/icons'
        filedialog.set_filename(icon)
        filter_image= Gtk.FileFilter()
        filter_image.set_name(_("Image Files"))
        filter_image.add_mime_type("image/png")
        filter_image.add_mime_type("image/x-svg")
        filter_image.add_mime_type("image/jpeg")
        filter_image.add_mime_type("image/gif")
        filter_image.add_mime_type("image/bmp")
        filter_image.add_mime_type("image/tiff")
        filter_image.add_mime_type("image/xpm")
        filter_image.add_mime_type("image/svg+xml")

        filter_any=Gtk.FileFilter()
        filter_any.set_name("All files")
        filter_any.add_pattern('*')
        filedialog.add_filter(filter_any)
        filedialog.add_filter(filter_image)
        response = filedialog.run()
        if response == Gtk.ResponseType.OK:

            newfile=filedialog.get_filename()
            if icon != newfile:
                icon=newfile

        filedialog.destroy()
        return icon
        
    def on_btn_ok_clicked(self, widget, data=None):
        """The user has elected to save the changes.
        Add functions to get all values from entries and store in a dictionary
        that will be used to update Desktop Action entry
        Called before the dialog returns Gtk.ResponseType.OK from run().
        """
        self.entry['Name']=self.nameentry.get_text()
        self.entry['Exec']=self.execentry.get_text()
        if self.quicklist.get_active():
            self.entry['OnlyShowIn']='Unity' 
        else:
            self.entry['OnlyShowIn']=''
        if self.QLname_entries != []:
            self.QLname_entries = [widget.get_text() for (val, widget) in self.QLname_entries if widget.get_text().strip() !=""]
            self.QLexec_entries = [widget.get_text() for widget in self.QLexec_entries if widget.get_text().strip() !=""]
        self.entry['Actions']['Names']=self.QLname_entries
        self.entry['Actions']['Execs']=self.QLexec_entries
        self.hide()
        
        pass

    def on_btn_cancel_clicked(self, widget, data=None):
        """The user has elected cancel changes.
        
        Called before the dialog returns Gtk.ResponseType.CANCEL for run()
        """
        self.hide()
        pass

class QuicklistItem(Gtk.Widget):
    def __init__(self,label='',execline=''):
        Gtk.Widget.__init__(self)
        
        
if __name__ == "__main__":
    entry={'Name':'Name1',
            'Icon':'file',
            'Exec':'glxgears',
            'OnlyShowIn':True}
    dialog = EdititemDialog(entry)
    dialog.show()
    
    Gtk.main()
