#!/bin/bash          
./GpuTest /test=pixmark_volplosion /width=1920 /height=1080 /fullscreen /benchmark
