#!/bin/bash          
#./GpuTest /test=tess_x8 /width=1920 /height=1080 /fullscreen /benchmark
#./GpuTest /test=tess_x16 /width=1920 /height=1080 /fullscreen /benchmark
./GpuTest /test=tess_x32 /width=1920 /height=1080 /fullscreen /benchmark
#./GpuTest /test=tess_x64 /width=1920 /height=1080 /fullscreen /benchmark
