#!/bin/bash          
./GpuTest /test=fur /width=1024 /height=640
