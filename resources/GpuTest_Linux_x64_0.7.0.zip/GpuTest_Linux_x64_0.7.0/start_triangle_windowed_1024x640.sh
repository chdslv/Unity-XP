#!/bin/bash          
./GpuTest /test=triangle /width=1024 /height=640
