#!/bin/bash          
./GpuTest /test=fur /width=1920 /height=1080 /fullscreen /benchmark
