#!/bin/bash          
#./GpuTest /test=tess_x8 /width=1024 /height=640
#./GpuTest /test=tess_x16 /width=1024 /height=640
./GpuTest /test=tess_x32 /width=1024 /height=640
#./GpuTest /test=tess_x64 /width=1024 /height=640
