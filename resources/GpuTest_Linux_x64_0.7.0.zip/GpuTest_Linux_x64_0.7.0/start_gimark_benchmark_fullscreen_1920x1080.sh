#!/bin/bash          
./GpuTest /test=gi /width=1920 /height=1080 /fullscreen /benchmark
