#!/bin/bash          
./GpuTest /test=triangle /width=1920 /height=1080 /fullscreen /benchmark
