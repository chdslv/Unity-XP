#!/bin/bash          
./GpuTest /test=plot3d /width=1024 /height=640
