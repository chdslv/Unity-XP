#!/bin/bash          
./GpuTest /test=pixmark_piano /width=1920 /height=1080 /fullscreen /benchmark
