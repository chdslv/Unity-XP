#!/bin/bash          
./GpuTest /test=gi /width=1024 /height=640
