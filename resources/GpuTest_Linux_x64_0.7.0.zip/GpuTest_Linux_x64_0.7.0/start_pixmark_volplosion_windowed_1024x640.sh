#!/bin/bash          
./GpuTest /test=pixmark_volplosion /width=1024 /height=640
