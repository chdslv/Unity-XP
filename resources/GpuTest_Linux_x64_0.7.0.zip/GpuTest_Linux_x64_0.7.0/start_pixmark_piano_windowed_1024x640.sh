#!/bin/bash          
./GpuTest /test=pixmark_piano /width=1024 /height=640
