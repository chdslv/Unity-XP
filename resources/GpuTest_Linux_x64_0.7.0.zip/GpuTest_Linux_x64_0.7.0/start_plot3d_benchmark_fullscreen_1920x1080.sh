#!/bin/bash          
./GpuTest /test=plot3d /width=1920 /height=1080 /fullscreen /benchmark
